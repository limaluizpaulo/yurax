# Cm Intelligence Front

## Configuração

| Propriedade            | Projeto                                                                                                       | Tipo        |
| ---------------------- | ------------------------------------------------------------------------------------------------------------- | ----------- |
| CM_INTELLIGENCE_SERVER | [Cm Intelligence Core](http://192.168.100.122/devsp/produtos-comunikime/cm-intelligence/cm-intelligence-core) | Obrigatório |
