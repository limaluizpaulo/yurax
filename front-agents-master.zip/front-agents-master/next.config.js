/* eslint-disable import/no-extraneous-dependencies */
const withBundleAnalyzer = require('@next/bundle-analyzer')({
  enabled: process.env.ANALYZE === 'true',
});

const { i18n } = require('./next-i18next.config');

module.exports = withBundleAnalyzer({
  // experimental: {
  //   appDir: true,
  // },
  eslint: {
    dirs: ['.'],
  },
  async rewrites() {
    return [
      {
        source: '/:path*',
        destination: '/:path*',
      },
    ];
  },
  poweredByHeader: false,
  trailingSlash: false,
  basePath: '',
  i18n,
  // You can remove `basePath` if you don't need it.
  reactStrictMode: true,
});
