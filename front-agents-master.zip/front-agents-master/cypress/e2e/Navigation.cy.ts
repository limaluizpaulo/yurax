import { pages } from './mock/pages';
import SignInPage from './utils/SignInPage.cy';

describe('Navigation', () => {
  describe('Static pages', () => {
    it('Should navigate to the login page, if not authenticated', () => {
      // Start from another page
      cy.visit('/dashboard');

      // Should be redirected to the login page
      cy.url().should('include', '/login');

      // Find a button with text "Logar"
      cy.findAllByText('Logar').should('exist');
    });

    pages.forEach((page) => {
      it(`Should navigate to the ${page.name} page`, () => {
        SignInPage.start();
        cy.get(`a[href="${page.url}"]`).as(page.name).should('exist');
        cy.visit(page.url);

        cy.url().should('include', page.url);
        cy.findByText(page.title).should('exist');
      });
    });
  });
});
