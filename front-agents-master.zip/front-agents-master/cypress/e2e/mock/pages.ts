export const pages = [
  {
    name: 'dashboard',
    title: 'Dashboard',
    url: '/dashboard',
  },
  {
    name: 'Grupo de Operador',
    title: 'Grupo de Operadores',
    url: '/workgroup',
  },
  {
    name: 'Aderência',
    title: 'Aderência',
    url: '/adherence',
  },
  {
    name: 'Escalas',
    title: 'Escalas',
    url: '/scale',
  },
  {
    name: 'Forecast',
    title: 'Forecast',
    url: '/forecast',
  },
];
