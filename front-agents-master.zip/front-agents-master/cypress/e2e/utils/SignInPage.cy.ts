class SignInPage {
  static visit() {
    cy.visit('/login');
    cy.url().should('include', '/login');
  }

  static getEmailError() {
    return cy.findByText('E-mail inválido');
  }

  static getPasswordError() {
    return cy.findByText('Senha inválida');
  }

  static fillEmail(email: string) {
    cy.get('input[name="email"]').as('field');
    cy.get('@field').clear();
    cy.get('@field').type(email);
  }

  static fillPassword(password: string) {
    cy.get('input[name="password"]').as('field');
    cy.get('@field').clear();
    cy.get('@field').type(password);
  }

  static start() {
    SignInPage.visit();

    SignInPage.fillEmail('felipe.nunes@comuniki.me');
    SignInPage.fillPassword('12345678');

    SignInPage.getEmailError().should('not.exist');
    SignInPage.getPasswordError().should('not.exist');

    cy.url().then((url) => {
      if (url.includes('/en')) {
        cy.log('English page');
        cy.findAllByText('Sign in').click();
      } else if (url.includes('/es')) {
        cy.log('Spanish page');
        cy.findAllByText('Iniciar Sesión').click();
      }
      cy.log('Portuguese page');
      cy.findAllByText('Logar').click();
    });
  }
}

export default SignInPage;
