import SignInPage from '../utils/SignInPage.cy';

describe('Translation', () => {
  it('Sidebar', () => {
    SignInPage.start();
  });
});
