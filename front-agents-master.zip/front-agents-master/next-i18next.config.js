module.exports = {
  i18n: {
    locales: ['en', 'pt-BR', 'es'],
    defaultLocale: 'pt-BR',
  },
};
