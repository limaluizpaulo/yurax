/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {},
  plugins: [require('daisyui')], // eslint-disable-line
  daisyui: {
    themes: [
      {
        cmk: {
          // eslint-disable-next-line global-require
          ...require('daisyui/src/colors/themes')['[data-theme=winter]'],
          primary: '#008ACC',
          neutral: '#262626',
          '--rounded-btn': '0.25rem',
        },
      },
      'dracula',
      'dark',
      'synthwave',
      'winter',
    ],
  },
};
