import LogoCmk from "../atom/Icons/LogoCmk";

const Loading = () => {
  return (
    <div className="flex fixed top-0 left-0 h-screen w-screen items-center justify-center">
      <LogoCmk />
    </div>
  );
};

export default Loading;
