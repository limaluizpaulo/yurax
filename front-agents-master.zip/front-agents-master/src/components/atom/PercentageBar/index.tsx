interface IProps {
  percentage: number;
  quantity: number;
}

const PercentageBar = ({ percentage, quantity }: IProps) => {
  return (
    <div className="w-36 relative h-7 flex justify-between items-center rounded-btn border-2 border-primary-content p-1">
      <div
        className="absolute rounded-[2px] self-start h-4 bg-success"
        style={{ width: `${percentage}%` }}
      />
      <h4 className="relative text-center w-full text-xs text-primary-content">
        {`${percentage}%`} ({quantity})
      </h4>
    </div>
  );
};

export default PercentageBar;
