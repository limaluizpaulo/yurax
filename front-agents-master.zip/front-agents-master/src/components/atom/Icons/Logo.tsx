import React from 'react';

function Logo(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="300"
      height="22"
      fill="none"
      viewBox="0 0 300 22"
    >
      <path fill="currentColor" d="M0 0H7V22H0z"></path>
      <path fill="currentColor" d="M217 7H224V22H217z"></path>
      <path fill="currentColor" d="M240 7H247V22H240z"></path>
      <path
        fill="currentColor"
        d="M243 0a4 4 0 014 4v3h-30V4a4 4 0 014-4h22z"
      ></path>
      <path fill="currentColor" d="M53 8H60V22H53z"></path>
      <path
        fill="currentColor"
        d="M70 0H76V27H70z"
        transform="rotate(90 70 0)"
      ></path>
      <path
        fill="currentColor"
        d="M72 8h8v14h-4a4 4 0 01-4-4V8zM96 0v6H72V4a4 4 0 014-4h20z"
      ></path>
      <path
        fill="currentColor"
        d="M96 8H102V32H96z"
        transform="rotate(90 96 8)"
      ></path>
      <path
        fill="currentColor"
        d="M96 16H102V32H96z"
        transform="rotate(90 96 16)"
      ></path>
      <path fill="currentColor" d="M98 0h8v22h-4a4 4 0 01-4-4V0z"></path>
      <path
        fill="currentColor"
        d="M122 16H128V32H122z"
        transform="rotate(90 122 16)"
      ></path>
      <path fill="currentColor" d="M124 0h8v22h-4a4 4 0 01-4-4V0z"></path>
      <path
        fill="currentColor"
        d="M148 16H154V32H148z"
        transform="rotate(90 148 16)"
      ></path>
      <path fill="currentColor" d="M150 0H157V22H150z"></path>
      <path
        fill="currentColor"
        d="M160 4a4 4 0 014-4h4v22h-4a4 4 0 01-4-4V4z"
      ></path>
      <path
        fill="currentColor"
        d="M187 0H193V19H187z"
        transform="rotate(90 187 0)"
      ></path>
      <path
        fill="currentColor"
        d="M187 22H194V33H187z"
        transform="rotate(-180 187 22)"
      ></path>
      <path
        fill="currentColor"
        d="M187 16H193V35H187z"
        transform="rotate(90 187 16)"
      ></path>
      <path
        fill="currentColor"
        fillRule="evenodd"
        d="M40 7a7 7 0 00-7-7H17a7 7 0 00-7 7v15h7V7h16v15h7V7z"
        clipRule="evenodd"
      ></path>
      <path
        fill="currentColor"
        d="M250 4a4 4 0 014-4h4v22h-4a4 4 0 01-4-4V4z"
      ></path>
      <path
        fill="currentColor"
        d="M273 0H279V15H273z"
        transform="rotate(90 273 0)"
      ></path>
      <path
        fill="currentColor"
        d="M273 16H279V31H273z"
        transform="rotate(90 273 16)"
      ></path>
      <path
        fill="currentColor"
        d="M276 8h8v14h-4a4 4 0 01-4-4V8zM300 0v6h-24V4a4 4 0 014-4h20z"
      ></path>
      <path
        fill="currentColor"
        d="M300 8H306V32H300z"
        transform="rotate(90 300 8)"
      ></path>
      <path
        fill="currentColor"
        d="M300 16H306V32H300z"
        transform="rotate(90 300 16)"
      ></path>
      <path
        fill="currentColor"
        d="M190 8h8v14h-4a4 4 0 01-4-4V8zM214 0v6h-24V4a4 4 0 014-4h20z"
      ></path>
      <path
        fill="currentColor"
        d="M214 8H220V32H214z"
        transform="rotate(90 214 8)"
      ></path>
      <path
        fill="currentColor"
        d="M214 16H220V32H214z"
        transform="rotate(90 214 16)"
      ></path>
    </svg>
  );
}

export default Logo;
