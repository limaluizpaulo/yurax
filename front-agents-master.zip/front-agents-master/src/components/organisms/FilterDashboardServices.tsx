import { useState } from "react";
import { ptBR } from "date-fns/locale";
import { DateRangePicker } from "react-next-dates";
import { useTranslation } from "react-i18next";

const FilterDashboardServices = () => {
  const { t } = useTranslation();
  const [date, setDate] = useState({
    startDate: new Date(),
    endDate: new Date()
  });

  return (
    <header className="flex gap-4">
      <div className="input-group flex-1">
        <label htmlFor="services" className="bg-primary label px-2">
          {t("services")}
        </label>
        <select
          name="services"
          id="services"
          className="select bg-base-200 h-full flex-1"
        >
          <option value="service-1">Service 1</option>
        </select>
      </div>
      <DateRangePicker
        locale={ptBR}
        startDate={date.startDate}
        endDate={date.endDate}
        maxDate={new Date()}
        onStartDateChange={(startDate: any) =>
          setDate({ startDate, endDate: date.endDate })
        }
        onEndDateChange={(endDate: any) =>
          setDate({ startDate: date.startDate, endDate })
        }
      >
        {({ startDateInputProps, endDateInputProps }) => (
          <>
            <div className="input-group w-fit">
              <label
                htmlFor="startDate"
                className="label bg-primary px-2 whitespace-nowrap"
              >
                {t("start date")}
              </label>
              <input
                name="startDate"
                id="startDate"
                className="input w-[14ch] border-2 border-transparent bg-base-200 hover:bg-base-300 focus:border-primary focus:bg-neutral focus:text-neutral-content focus:outline-none"
                {...startDateInputProps}
                placeholder="dd/mm/aaaa"
              />
            </div>
            <div className="input-group w-fit">
              <label
                htmlFor="endlDate"
                className="label bg-primary px-2 whitespace-nowrap"
              >
                {t("end date")}
              </label>
              <input
                name="endDate"
                id="endDate"
                className="input w-[14ch] border-2 border-transparent bg-base-200 hover:bg-base-300 focus:border-primary focus:bg-neutral focus:text-neutral-content focus:outline-none"
                {...endDateInputProps}
                placeholder="dd/mm/aaaa"
              />
            </div>
          </>
        )}
      </DateRangePicker>
      <button type="button" className="btn btn-primary">
        {t("filter")}
      </button>
      <button type="button" className="btn">
        {t("clear filter")}
      </button>
    </header>
  );
};

export default FilterDashboardServices;
