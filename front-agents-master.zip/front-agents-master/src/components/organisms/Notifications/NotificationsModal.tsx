// eslint-disable-line import/no-extraneous-dependencies
import { useSelector } from "react-redux"; // eslint-disable-line import/no-extraneous-dependencies

import { selectNotifications } from "@/stores/notificationsSlice";

const NotificationsModal = () => {
  // const dispatch = useDispatch();
  const notifications = useSelector(selectNotifications);

  return (
    <div>
      <ul className="flex flex-col gap-4">
        {notifications?.map(({ description, id, title }) => (
          <li
            key={id}
            className="card bg-neutral transition-all hover:bg-neutral/75 hover:shadow-md"
          >
            <div className="card-body p-4">
              <h2 className="card-title text-neutral-content">{title}</h2>
              <p className=" text-gray-500">{description}</p>
              <span className="ml-auto text-neutral-content">
                {/* {formatDate(createdAt)} */}
              </span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default NotificationsModal;
