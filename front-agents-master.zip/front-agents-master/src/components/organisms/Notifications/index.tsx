import { Icon } from "@iconify/react"; // eslint-disable-line import/no-extraneous-dependencies
import { useState } from "react";
import { useTranslation } from "react-i18next"; // eslint-disable-line import/no-extraneous-dependencies
import { useSelector } from "react-redux"; // eslint-disable-line import/no-extraneous-dependencies

import { selectNotifications } from "@/stores/notificationsSlice";

import CustomModal from "../CustomModal";
import NotificationsModal from "./NotificationsModal";

const Notifications = () => {
  const notifications = useSelector(selectNotifications);
  const { t } = useTranslation(["common"]);
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <CustomModal title="Notificações" isOpen={isOpen} setIsOpen={setIsOpen}>
        <NotificationsModal />
      </CustomModal>
      <div
        className="tooltip tooltip-bottom"
        data-tip={t("notifications") ?? ""}
      >
        <button
          type="button"
          className="btn-ghost btn-circle btn"
          onClick={() => setIsOpen(true)}
        >
          <div className="indicator">
            <span className="badge-primary badge indicator-item h-4 w-4 rounded-full p-1 text-[8px]">
              {notifications?.length}
            </span>
            <Icon icon="ph:bell-fill" className="text-xl" />
          </div>
        </button>
      </div>
    </div>
  );
};

export default Notifications;
