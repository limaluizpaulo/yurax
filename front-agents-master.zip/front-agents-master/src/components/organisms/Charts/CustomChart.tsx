import { TFunction } from "i18next";
import { useMemo } from "react";
import Chart from "../Chart";

// const chartData = {};

interface ICustomChartProps<T> {
  defaultData: T[];
  visibleLables: string[];
  notVisibleLables: string[];
  translation: TFunction<string, undefined, string>;
  extraFn: (
    data: T[],
    translation: TFunction<string, undefined, string>
  ) => {
    data: any;
    columns: any;
  };
}

const CustomChart: <T extends any>(props: ICustomChartProps<T>) => any = ({
  defaultData,
  visibleLables,
  notVisibleLables = [],
  translation,
  extraFn
}) => {
  const labels = useMemo(() => {
    if (visibleLables === undefined) {
      return (
        Object.keys(defaultData[0] as any[]).reduce((acc: any, item) => {
          if (notVisibleLables.includes(item)) return acc;

          return acc.push(translation(item).toString());
        }),
        [] as string[]
      );
    }
    if (visibleLables.length === 0) return [];

    return visibleLables;
  }, [defaultData]);

  const chartData = useMemo(() => {
    return extraFn(defaultData, translation);
  }, [defaultData]);

  return (
    <Chart className="h-full w-full" height={400} width="100%" {...chartData} />
  );
};

export default CustomChart;
