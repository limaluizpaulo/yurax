import { useMemo } from "react";
import Chart from "../../Chart";
import { agentAdherencesToChart } from "@/helper/charts";

interface IAdherences {
  average_breaks_adherence: number | null;
  average_total_adherence: number | null;
}

const Adherences = ({
  data,
  isFullscreen
}: {
  data: IAdherences;
  isFullscreen: boolean;
}) => {
  console.log("Current adherence chart: ", data);
  const chartData: any = useMemo(() => {
    if (data !== undefined && data.average_total_adherence) return agentAdherencesToChart(data.average_total_adherence);
    return { options: {}, series: [] };
  }, [data]);

  console.log(chartData.series);

  return (
    <Chart
      options={chartData.options}
      series={chartData.series}
      type="donut"
      width={isFullscreen ? 800 : 360}
      height={isFullscreen ? 600 : 240}
    />
  );
};

export default Adherences;
