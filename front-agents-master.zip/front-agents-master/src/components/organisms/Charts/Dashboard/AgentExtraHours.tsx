import { useMemo } from "react";

import { AgentExtraHoursToChart } from "@/helper/charts";

import Chart from "../../Chart";

const AgentExtraHours = ({
  data,
  isFullscreen,
  agent
}: {
  data: number;
  isFullscreen: boolean;
  agent: any;
}) => {
  const chartData: any = useMemo(() => {
    if (data !== undefined) return AgentExtraHoursToChart(data, agent);
    return { options: {}, series: [] };
  }, [data]);

  return (
    <Chart
      options={chartData.options}
      series={chartData.series}
      type="donut"
      width={isFullscreen ? 800 : 360}
      height={isFullscreen ? 600 : 240}
    />
  );
};

export default AgentExtraHours;
