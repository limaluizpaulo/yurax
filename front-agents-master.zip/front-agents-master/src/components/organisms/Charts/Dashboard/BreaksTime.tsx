import { useMemo } from "react";
import Chart from "../../Chart";
import { BreakTimeDataToChart } from "@/helper/charts/dashboard/breakTime";

interface IBreakTime {
  total_all_brks_time_scaled: number | null;
  total_all_brks_time_worked: number | null;
}

const BreaksTime = ({
  data,
  isFullscreen,
  agent
}: {
  data: IBreakTime;
  isFullscreen: boolean;
  agent: { firstName: string }
}) => {
  console.log("Current break time chart: ", data, agent);
  const chartData: any = useMemo(() => {
    if (data !== undefined) return BreakTimeDataToChart(data, agent);
    return { options: {}, series: [] };
  }, [data]);

  return (
    <Chart
      options={chartData.options}
      series={chartData.series}
      type="bar"
      width={isFullscreen ? 800 : 360}
      height={isFullscreen ? 600 : 240}
    />
  );
};

export default BreaksTime;
