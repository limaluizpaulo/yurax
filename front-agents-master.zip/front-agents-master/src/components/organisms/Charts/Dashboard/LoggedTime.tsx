import { useMemo } from "react";

import { LoggedTimeDataToChart } from "@/helper/charts";

import Chart from "../../Chart";
import { ILoggedTime } from "@/helper/charts/dashboard/loggedTime";

const LoggedTime = ({
  data,
  isFullscreen,
  agent
}: {
  data: ILoggedTime;
  isFullscreen: boolean;
  agent: { firstName: string };
}) => {
  const chartData: any = useMemo(() => {
    if (data !== undefined) return LoggedTimeDataToChart(data, agent);
    return { options: {}, series: [] };
  }, [data]);

  return (
    <Chart
      options={chartData.options}
      series={chartData.series}
      type="bar"
      width={isFullscreen ? 800 : 360}
      height={isFullscreen ? 600 : 240}
    />
  );
};

export default LoggedTime;
