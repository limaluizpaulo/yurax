import { useMemo } from "react";

import { totalAbsenteismToChart } from "@/helper/charts";

interface IAbsenteism {
  total_absenteism: number | null;
}

import Chart from "../../Chart";

const Absenteism = ({
  data,
  isFullscreen,
  agent
}: {
  data: IAbsenteism;
  isFullscreen: boolean;
  agent: { firstName: string };
}) => {
  const { options, series }: any = useMemo(() => {
    if (data !== undefined && data.total_absenteism) return totalAbsenteismToChart(data.total_absenteism, agent);

    return { options: {}, series: [] };
  }, [data]);
  return (
    <Chart
      options={options}
      series={series}
      type="radialBar"
      width={isFullscreen ? 800 : 360}
      height={isFullscreen ? 600 : 240}
    />
  );
};

export default Absenteism;
