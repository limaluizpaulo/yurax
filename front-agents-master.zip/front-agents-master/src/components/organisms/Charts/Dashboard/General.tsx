/* eslint-disable import/no-extraneous-dependencies */
import {Icon} from "@iconify/react";
import {useState} from "react";
import {useTranslation} from "react-i18next";

import {
  Absenteism,
  Adherences,
  BreaksTime,
  LoggedTime,
  AgentExtraHours
} from ".";
import CustomModal from "../../CustomModal";
import {useQuery} from "@tanstack/react-query";
import {ENV} from "@/constants/env.enum";
import axios from "axios";
import {auth} from "@/stores/authSlice";
import {useSelector} from "react-redux";

const charts = [
  {
    id: "absenteeism",
    name: "Absenteeismo",
    icon: "mdi:chart-line",
    component: (props: any) => <Absenteism {...props} />
  },
  /*{
    id: "totalWorkGroupsExtraHours",
    name: "Horas Extras",
    icon: "mdi:chart-line",
    component: (props: any) => <AgentExtraHours {...props} />
  },*/
  {
    id: "mediumWorkGroupsAdherence",
    name: "Aderência",
    icon: "mdi:chart-line",
    component: (props: any) => <Adherences {...props} />
  },
  {
    id: "mediumWorkGroupsLoggedTimes",
    name: "Tempo Logado",
    icon: "mdi:chart-line",
    component: (props: any) => <LoggedTime {...props} />
  },
  {
    id: "mediumWorkGroupsBreaksTimes",
    name: "Tempo de Pausa",
    icon: "mdi:chart-line",
    component: (props: any) => <BreaksTime {...props} />
  }
];

const GeneralDashboardGraphs = ({data: graphsData}: { data: any }) => {
  const [selectedGraph, setSelectedGraph] = useState(-1);
  const {token, user} = useSelector(auth);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const {t} = useTranslation();



  return (
    <div className="flex h-full flex-col gap-4">
      <header className="flex justify-between gap-4">
        {/* <h2 className="text-4xl font-bold">{t("charts").toString()}</h2> */}
        <ul className="grid grid-flow-col items-end justify-end gap-1">
          {charts.map((chart, index) => {
            if (selectedGraph === index || selectedGraph === -1) return null;

            return (
              <li
                key={index}
                className="flex items-center gap-2 rounded-md bg-neutral py-1 px-2"
              >
                <span className="text-xs capitalize">{t(chart.name)}</span>
                <button
                  type="button"
                  className="btn-ghost btn-sm btn-circle btn"
                  title={t("maximize").toString()}
                  onClick={() => setSelectedGraph(index)}
                >
                  <Icon
                    icon="material-symbols:expand-content"
                    className="h-6 w-6"
                  />
                </button>
              </li>
            );
          })}
        </ul>
      </header>
      <div className="grid h-full gap-4 overflow-y-auto lg:grid-cols-2 lg:grid-rows-2">
        {charts.map((chart, index) => {
          if (selectedGraph !== -1 && selectedGraph !== index) return null;
          return (
            <div
              key={chart.id}
              className={`rounded-btn flex h-full w-full flex-col bg-neutral p-4 transition-all 
              ${
                index === selectedGraph
                  ? "col-span-3 row-span-2"
                  : "opacity-80 hover:opacity-100"
              }`}
            >
              <header className="flex justify-between">
                <h2 className="text-xl font-bold capitalize">
                  {t(chart.name)}
                </h2>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    className="btn-ghost btn-xs btn-circle btn bg-yellow-500 hover:bg-yellow-400"
                    title={t("maximize").toString()}
                    onClick={() =>
                      setSelectedGraph((prevIndex) =>
                        prevIndex === index ? -1 : index
                      )
                    }
                  >
                    <Icon
                      icon={
                        selectedGraph === index
                          ? "tabler:arrows-diagonal-minimize"
                          : "material-symbols:expand-content"
                      }
                      hFlip={selectedGraph === index}
                      className="h-4 w-4 text-neutral"
                    />
                  </button>
                  <button
                    type="button"
                    className="btn-xs btn-circle btn bg-red-500 hover:bg-red-400"
                    title={t("close").toString()}
                  >
                    <Icon icon="ph:x" className="h-4 w-4 text-neutral"/>
                  </button>
                  <button
                    className="btn-ghost btn-sm btn-circle btn"
                    onClick={() => setIsModalOpen(true)}
                    title={t("config").toString()}
                  >
                    <Icon icon="ph:gear-six-fill" className="h-6 w-6"/>
                  </button>
                </div>
              </header>
              <div className="flex-1">

                <div className="flex h-full w-full items-center justify-center">
                  {chart.component({
                    data: (graphsData as any),
                    isFullscreen: selectedGraph === index,
                    agent: user
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <CustomModal
        isOpen={isModalOpen}
        setIsOpen={setIsModalOpen}
        title={t("config")}
        closeActions="normal"
      >
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <label htmlFor="chart" className="text-lg font-bold">
              {t("chart")}
            </label>
            <select
              name="chart"
              id="chart"
              className="select bg-base-200"
              defaultValue={selectedGraph ?? "none"}
              onChange={(e) => setSelectedGraph(parseInt(e.target.value))}
            >
              <option value="none" disabled>
                {t("none")}
              </option>
              {charts.map((chart, index) => (
                <option key={index} value={index}>
                  {t(chart.name)}
                </option>
              ))}
            </select>
          </div>
        </div>
      </CustomModal>
    </div>
  );
};

export default GeneralDashboardGraphs;
