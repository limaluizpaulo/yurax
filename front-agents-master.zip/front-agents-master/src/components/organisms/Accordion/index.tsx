import { Icon } from "@iconify/react";
import { AnimatePresence, motion } from "framer-motion";
import { ReactElement, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { twMerge } from "tailwind-merge";

interface IProps {
  title: string;
  type?: "select" | "none";
  titleIcon?: string;
  defaultOpen?: boolean;
  children: () => ReactElement[];
  selectAll?: () => void;
  gap?: boolean;
  translation?: string;
  isAllSelected?: boolean;
}

const Accordion = ({
  title,
  titleIcon,
  children,
  defaultOpen,
  selectAll,
  gap = false,
  type = "none",
  isAllSelected = false
}: IProps) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(defaultOpen);
  useEffect(() => {
    if (type === "select") {
      selectAll?.();
    }
  }, []);
  return (
    <>
      <button
        className="btn btn-primary w-full justify-between"
        onClick={() => setIsOpen((p) => !p)}
      >
        <span className="flex gap-2">
          {titleIcon && <Icon icon={titleIcon} />} {title}
        </span>
        <Icon icon="bxs:down-arrow" vFlip={isOpen} />
      </button>
      <AnimatePresence mode="wait">
        {isOpen && (
          <motion.ul
            key="list"
            layout
            className={twMerge(
              "flex flex-col ml-4 pl-4 border border-transparent border-l-neutral-content",
              gap && "gap-2"
            )}
          >
            {type === "select" && (
              <motion.li className="flex gap-4 px-2 rounded-btn hover:bg-base-100 items-center transition-colors [&:has(input:checked)]:bg-primary">
                <input
                  type="checkbox"
                  name={`${title}-select-all`}
                  id={`${title}-select-all`}
                  checked={isAllSelected}
                  onChange={() => {
                    selectAll?.();
                  }}
                  className="checkbox peer checkbox-sm"
                />

                <label
                  htmlFor={`${title}-select-all`}
                  className="label flex-1 py-2 peer-checked:text-primary-content cursor-pointer"
                >
                  <span className="">
                    {t("common:select")} {t("common:all")}
                  </span>
                </label>
              </motion.li>
            )}
            {children()}
          </motion.ul>
        )}
      </AnimatePresence>
    </>
  );
};

export default Accordion;
