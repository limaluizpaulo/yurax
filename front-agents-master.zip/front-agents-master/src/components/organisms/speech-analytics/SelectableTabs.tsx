import { Icon } from "@iconify/react";

type tab = "initial_page" | "command_center" | "customize_dashboard" | "help";

export const tabs: {
  label: tab;
  icon: string;
}[] = [
  {
    label: "initial_page",
    icon: "uil:brain"
  },
  {
    label: "command_center",
    icon: "material-symbols:space-dashboard-rounded"
  },
  {
    label: "customize_dashboard",
    icon: "ic:round-record-voice-over"
  },
  {
    label: "help",
    icon: "ic:round-record-voice-over"
  }
];

interface IProps {
  currentSelected: number;
  setCurrentSelected: (index: number) => void;
}

const SelectableTabs = ({ currentSelected, setCurrentSelected }: IProps) => {
  return (
    <>
      <ul className="tabs w-full py-2">
        {tabs.map((tab, index) => {
          return (
            <li
              key={index}
              className={`tab tab-lg tab-lifted ${
                index === currentSelected ? "tab-active" : ""
              }`}
              onClick={() => setCurrentSelected(index)}
            >
              <Icon icon={tab.icon} className="mr-2" />
              <span>{tab.label}</span>
            </li>
          );
        })}
      </ul>
    </>
  );
};

export default SelectableTabs;
