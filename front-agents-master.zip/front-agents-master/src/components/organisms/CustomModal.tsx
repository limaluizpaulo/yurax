import { Dialog } from "@headlessui/react"; // eslint-disable-line import/no-extraneous-dependencies
import { AnimatePresence, motion } from "framer-motion";
import type { ReactNode } from "react";
import { useTranslation } from "react-i18next";
// eslint-disable-line import/no-extraneous-dependencies

const CustomModal = ({
  title,
  isOpen,
  setIsOpen,
  customFn,
  children,
  closeActions
}: {
  title: string;
  isOpen: boolean;
  setIsOpen: (value: boolean) => void;
  children: ReactNode;
  customFn?: () => void;
  closeActions?: string;
}) => {
  const { t } = useTranslation();
  return (
    <AnimatePresence mode="wait">
      <Dialog
        className="absolute top-0 z-10 flex h-screen w-screen items-center justify-center bg-black/50"
        open={isOpen}
        onClose={() => setIsOpen(false)}
      >
        <motion.div
          initial={{
            opacity: 0.6,
            y: "-100%",
            scaleY: 0
          }}
          animate={{
            opacity: 1,
            y: 0,
            scaleY: 1
          }}
          exit={{
            opacity: 0,
            y: "-100%",
            scaleY: 0
          }}
          className="w-full "
        >
          <Dialog.Panel className="modal-box mx-auto flex flex-col gap-4">
            <Dialog.Title className="text-2xl font-medium">
              {title}
            </Dialog.Title>
            {children}
            {!!closeActions && (
              <div className="flex justify-end gap-4">
                <button
                  className="btn-error btn"
                  onClick={() => setIsOpen(false)}
                >
                  {t("cancel")}
                </button>
                <button
                  className="btn"
                  onClick={() => {
                    setIsOpen(false);
                    if (customFn) customFn();
                  }}
                >
                  Ok
                </button>
              </div>
            )}
          </Dialog.Panel>
        </motion.div>
      </Dialog>
    </AnimatePresence>
  );
};

export default CustomModal;
