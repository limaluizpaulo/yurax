import { Icon } from "@iconify/react";
import { Table, flexRender } from "@tanstack/react-table";
import { useTranslation } from "react-i18next";

interface ITableHeader {
  table: Table<any>;
  shouldSelect: boolean;
  setRowSelection: ((_value: any) => void) | undefined;
  data: any[];
  action: any;
}

const TableHeader = ({
  table,
  shouldSelect,
  setRowSelection,
  data,
  action
}: ITableHeader) => {
  const { t } = useTranslation(["common"]);

  return (
    <thead>
      {table.getHeaderGroups().map((headerGroup) => (
        <tr key={headerGroup.id}>
          {shouldSelect && (
            <th>
              <input
                checked={table.getIsAllRowsSelected()}
                onChange={() => {
                  table.toggleAllRowsSelected();
                  setRowSelection?.(
                    !table.getIsAllRowsSelected()
                      ? data.map((value) => value._id)
                      : []
                  );
                }}
                className="checkbox rounded-btn"
                type="checkbox"
                name="select-all"
                id="select-all"
              />
            </th>
          )}
          {headerGroup.headers.map((header) => (
            <th key={header.id}>
              {header.isPlaceholder ? null : (
                <div
                  {...{
                    className: `
                        flex gap-2 
                        ${
                          header.column.getCanSort()
                            ? "cursor-pointer select-none"
                            : ""
                        }`,
                    onClick: header.column.getToggleSortingHandler()
                  }}
                >
                  {flexRender(
                    header.column.columnDef.header,
                    header.getContext()
                  )}
                  <div className="relative flex h-full w-4 flex-col">
                    <Icon
                      icon="material-symbols:arrow-drop-up-rounded"
                      className={`absolute -top-1 text-xl transition-colors ${
                        header.column.getIsSorted() === "asc"
                          ? "text-white"
                          : "opacity-50"
                      }`}
                    />
                    <Icon
                      icon="material-symbols:arrow-drop-down-rounded"
                      className={`absolute top-1 text-xl transition-colors ${
                        header.column.getIsSorted() === "desc"
                          ? "text-white"
                          : "opacity-50"
                      }`}
                    />
                  </div>
                </div>
              )}
            </th>
          ))}
          {action && <th className="text-center">{t("actions")}</th>}
        </tr>
      ))}
    </thead>
  );
};

export default TableHeader;
