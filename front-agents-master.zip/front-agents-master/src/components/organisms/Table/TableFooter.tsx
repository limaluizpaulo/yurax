import { Table } from "@tanstack/react-table";
import { useTranslation } from "react-i18next";

interface ITableFooter {
  table: Table<any>;
}

const TableFooter = (props: ITableFooter) => {
  const { t } = useTranslation(["common"]);

  return (
    <div className="flex w-full justify-center gap-2 rounded-b-md bg-base-200 py-2">
      <button
        className="btn"
        onClick={() => props.table.setPageIndex(0)}
        disabled={!props.table.getCanPreviousPage()}
      >
        {"<<"}
      </button>
      <button
        className="btn"
        onClick={() => props.table.previousPage()}
        disabled={!props.table.getCanPreviousPage()}
      >
        {"<"}
      </button>
      <button
        className="btn"
        onClick={() => props.table.nextPage()}
        disabled={!props.table.getCanNextPage()}
      >
        {">"}
      </button>
      <button
        className="btn"
        onClick={() => props.table.setPageIndex(props.table.getPageCount() - 1)}
        disabled={!props.table.getCanNextPage()}
      >
        {">>"}
      </button>
      <span className="flex items-center gap-1">
        <div>{t("table.page")}</div>
        <strong>
          {props.table.getState().pagination.pageIndex + 1} {t("of")}{" "}
          {props.table.getPageCount()}
        </strong>
      </span>
      <span className="flex items-center gap-1">
        | {t("table.go-to-page")}
        <input
          type="number"
          defaultValue={props.table.getState().pagination.pageIndex + 1}
          onChange={(e) => {
            const page = e.target.value ? Number(e.target.value) - 1 : 0;
            props.table.setPageIndex(page);
          }}
          placeholder="pg:. 18"
          className="input-bordered input w-20"
        />
      </span>
      <select
        className="select"
        value={props.table.getState().pagination.pageSize}
        onChange={(e) => {
          props.table.setPageSize(Number(e.target.value));
        }}
      >
        {[10, 20, 30, 40, 50].map((pageSize) => (
          <option key={pageSize} value={pageSize}>
            {t("show")} {pageSize}
          </option>
        ))}
      </select>
    </div>
  );
};

export default TableFooter;
