/* eslint-disable import/no-extraneous-dependencies */
import {Icon} from "@iconify/react";
import {rankItem} from "@tanstack/match-sorter-utils";
import type {
  ColumnOrderState,
  FilterFn,
  SortingState
} from "@tanstack/react-table";
import {
  getCoreRowModel,
  getFacetedMinMaxValues,
  getFacetedRowModel,
  getFacetedUniqueValues,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable
} from "@tanstack/react-table";
import {useEffect, useState} from "react";

import {useTranslation} from "react-i18next";
import {DebouncedInput} from "./DebounceInput";
import TableActions from "./TableActions";
import TableFooter from "./TableFooter";
import TableBody from "./TableBody";
import TableHeader from "./TableHeader";

const fuzzyFilter: FilterFn<any> = (row, columnId, value, addMeta) => {
  const itemRank = rankItem(row.getValue(columnId), value);
  addMeta({
    itemRank
  });

  return itemRank.passed;
};

const CustomTable = ({
                       columns,
                       defaultData,
                       pageSize = 10,
                       shouldSelect = false,
                       rowSelection = [],
                       setRowSelection,
                       actions,
                       action
                     }: {
  columns: any[];
  defaultData: any[];
  pageSize?: 10 | 20 | 30 | 40 | 50;
  shouldSelect?: boolean;
  rowSelection?: any[];
  setRowSelection?: (_value: any) => void;
  actions?: any;
  action?: any;
}) => {
  const [data, setData] = useState(() => [...defaultData]);
  useEffect(() => {
    setData([...defaultData]);
  }, [defaultData, columns]);

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [columnVisibility, changeColumnVisibility] = useState({});
  const [sorting, setSorting] = useState<SortingState>([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [columnOrder, changeColumnOrder] = useState<ColumnOrderState>([]);

  const table = useReactTable({
    data,
    columns,
    filterFns: {
      fuzzy: fuzzyFilter
    },
    state: {
      columnVisibility,
      columnOrder,
      sorting,
      globalFilter
    },
    initialState: {
      pagination: {
        pageSize
      }
    },
    onSortingChange: setSorting,
    onColumnVisibilityChange: changeColumnVisibility,
    onGlobalFilterChange: setGlobalFilter,
    enableMultiRowSelection: true,
    onColumnOrderChange: changeColumnOrder,
    getCoreRowModel: getCoreRowModel(),
    // debugTable: true,
    // debugHeaders: true,
    // debugColumns: true,
    globalFilterFn: fuzzyFilter,
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getFacetedRowModel: getFacetedRowModel(),
    getFacetedUniqueValues: getFacetedUniqueValues(),
    getFacetedMinMaxValues: getFacetedMinMaxValues()
  });

  const {t} = useTranslation(["common"]);

  return (
    <div className="flex w-full max-w-full flex-col">
      <div className="mb-4 flex justify-between gap-4">
        {shouldSelect && (
          <div className="flex items-center gap-2">
            <TableActions
              options={actions}
              toggleRows={() => {
                table.toggleAllRowsSelected(false);
                setRowSelection?.([]);
              }}
              disabled={rowSelection.length === 0}
            />
          </div>
        )}
        <div className="self-end">
          <DebouncedInput
            value={globalFilter ?? ""}
            onChange={(value) => setGlobalFilter(String(value))}
            className="input-bordered input bg-base-200"
            placeholder={`${t("search")}...`}
          />
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <input
              {...{
                type: "checkbox",
                className: "checkbox checkbox-md rounded-btn",
                checked: table.getIsAllColumnsVisible(),
                id: "toggle-all",
                onChange: table.getToggleAllColumnsVisibilityHandler()
              }}
            />
            <label className="label cursor-pointer" htmlFor="toggle-all">
              {t("toggle-all")}
            </label>
          </div>
          <div className="relative">
            <button
              type="button"
              className="btn-primary btn"
              onClick={() => setIsMenuOpen((prev: any) => !prev)}
            >
              {t("table.visible-columns")}
            </button>
            {isMenuOpen && (
              <ul className="dropdown-content menu rounded-box absolute right-0 z-10 mt-2 bg-base-200 p-2">
                {table.getAllLeafColumns().map((column) => {
                  return (
                    <li key={column.id}>
                      <div className="flex items-center gap-2 px-4">
                        <input
                          {...{
                            id: column.id,
                            type: "checkbox",
                            className: "checkbox checkbox-sm rounded-btn",
                            checked: column.getIsVisible(),
                            onChange: column.getToggleVisibilityHandler()
                          }}
                        />
                        <label
                          className="label cursor-pointer whitespace-nowrap"
                          htmlFor={column.id}
                        >
                          {column.columnDef.header as string}
                        </label>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </div>
      <div className="overflow-auto">
        <table className="table-zebra table w-full">
          <TableHeader
            data={data}
            table={table}
            setRowSelection={setRowSelection}
            shouldSelect={shouldSelect}
            action={action}
          />
          {
            data?.length > 0 &&
              <TableBody
                  getRowModel={table.getRowModel}
                  setRowSelection={setRowSelection}
                  rowSelection={rowSelection}
                  shouldSelect={shouldSelect}
                  action={action}
              />
          }
        </table>
      </div>
      <TableFooter table={table}/>
    </div>
  );
};

export default CustomTable;
