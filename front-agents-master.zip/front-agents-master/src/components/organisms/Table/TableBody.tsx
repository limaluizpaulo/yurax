import { RowModel, flexRender } from "@tanstack/react-table";
import { Fragment } from "react";

interface ITableBody {
  getRowModel: () => RowModel<any>;
  shouldSelect: boolean;
  rowSelection: any[];
  setRowSelection: ((_value: any) => void) | undefined;
  action: any;
}

const TableBody = ({
  getRowModel,
  setRowSelection,
  action,
  rowSelection,
  shouldSelect
}: ITableBody) => {

  return (
    <tbody>
      {getRowModel().rows.map((row, rowIndex) => (
        <tr key={row?.id}>
          {shouldSelect && (
            <>
              <td>
                <input
                  type="checkbox"
                  checked={row.getIsSelected()}
                  className="checkbox checkbox-sm rounded-btn"
                  name="select"
                  onChange={() => {
                    row.toggleSelected();
                    setRowSelection?.(
                      !row.getIsSelected()
                        ? [...rowSelection, row.original._id]
                        : rowSelection.filter((id) => id !== row.original._id)
                    );
                  }}
                  id={`select-${row.id}`}
                />
              </td>
            </>
          )}
          {row.getVisibleCells().map((cell, index) => (
            <Fragment key={cell.id}>
              <td>
                {flexRender(cell.column.columnDef.cell, cell.getContext())}
              </td>
              {index === row.getVisibleCells()?.length - 1 && action && (
                <td className="w-[5rem]">{action?.(rowIndex)}</td>
              )}
            </Fragment>
          ))}
        </tr>
      ))}
    </tbody>
  );
};

export default TableBody;
