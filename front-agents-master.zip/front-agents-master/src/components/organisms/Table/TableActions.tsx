import { Menu } from "@headlessui/react";
import { useTranslation } from "react-i18next";

interface IProps {
  options: { [key: string]: () => void };
  disabled: boolean;
  toggleRows: () => void;
}

const TableActions = ({ options, disabled, toggleRows }: IProps) => {
  const { t } = useTranslation();
  return (
    <div className="dropdown-bottom dropdown">
      <Menu>
        <Menu.Button
          disabled={disabled}
          className="btn btn-primary rounded-btn"
        >
          {t("actions")}
        </Menu.Button>
        <Menu.Items
          as="ul"
          className="dropdown-content menu rounded-box right-0 mt-2 bg-base-200 p-2 shadow-lg"
        >
          <Menu.Item as="li">
            {Object.entries((options as any) ?? {}).map(([key, value]) => {
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    (value as any)();
                    toggleRows();
                  }}
                  className="btn btn-ghost rounded-btn"
                >
                  {t(key)}
                </button>
              );
            })}
          </Menu.Item>
        </Menu.Items>
      </Menu>
    </div>
  );
};

export default TableActions;
