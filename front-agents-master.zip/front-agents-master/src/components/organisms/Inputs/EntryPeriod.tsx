import { memo, useCallback, useRef, useState } from "react";
import { twMerge } from "tailwind-merge";

const InputEntry = ({
  onChange,
  minEntry,
  defaultValue,
  extraClassName = "",
  label
}: {
  onChange?: (_value: {
    formattedValue: string;
    value: string;
    target: HTMLInputElement;
  }) => void;
  minEntry?: string;
  extraClassName?: string;
  label?: string;
  defaultValue?: string;
}) => {
  const [value, changeValue] = useState<string>(
    defaultValue?.replace(/[^0-9.]/g, "") ?? ""
  );
  const inputRef = useRef<HTMLInputElement>(null);

  // console.log(minEntry);

  const handlePosition = () => {
    const currentPosition = value.length > 2 ? value.length + 1 : value.length;
    setTimeout(() => {
      inputRef.current?.setSelectionRange(
        currentPosition,
        currentPosition,
        "forward"
      );
    }, 0);
  };

  const newValue = useCallback(() => {
    handlePosition();
    let updatedValue = "__:__";
    if (value.length === 1) updatedValue = `${value}_:__`;
    if (value.length === 2) updatedValue = `${value}:__`;
    if (value.length === 3)
      updatedValue = `${value.slice(0, 2)}:${value.slice(2, 3)}_`;
    if (value.length === 4)
      updatedValue = `${value.slice(0, 2)}:${value.slice(2, 4)}`;

    return updatedValue;
  }, [value]);

  console.log(minEntry);

  return (
    <>
      <div key={label} className={twMerge(label && "input-group")}>
        {label && <label className="label bg-primary px-2">{label}</label>}
        <input
          type="text"
          ref={inputRef}
          className={twMerge(
            "input bg-neutral focus:outline-none disabled:bg-neutral/50 disabled:text-neutral-content/50 focus:border-primary hover:border-primary/50",
            extraClassName
          )}
          value={newValue()}
          disabled={
            minEntry?.replace(/[^0-9.]/g, "").length! < 4 ? true : false
          }
          placeholder="00:00"
          onClick={() => {
            if (inputRef.current === null) return;
            handlePosition();
          }}
          onKeyDown={(e) => {
            let char = Number(e.key);

            console.log("Updating: ", value);

            if (e.key === "Backspace") {
              console.log(inputRef.current?.selectionStart);
              changeValue((currentValue) => currentValue.slice(0, -1));

              console.log("Updated: ", value);
              return;
            }

            if (isNaN(char) || value.length === 4) return handlePosition();

            if (value.length === 0) {
              if (minEntry) {
                if (Number(minEntry[0]) > char) char = Number(minEntry[0]);
                else if (char > 2) char = 2;
              } else if (char > 2) char = 2;
            }

            if (value.length === 1) {
              if (minEntry) {
                console.log("minEntry: ", minEntry);
                console.log("value: ", value);
                if (Number(minEntry[1]) > char && value[0] === minEntry[0])
                  char = Number(minEntry[1]);
                else if (value[0] === "2" && char > 3) char = 3;
              } else if (value[0] === "2" && char > 3) char = 3;
            }

            if (value.length === 2) {
              if (minEntry) {
                if (Number(minEntry[2]) > char && minEntry[1] === value[1])
                  char = Number(minEntry[2]);
                else if (char > 5) char = 5;
              } else if (char > 5) char = 5;
            }

            if (value.length === 3) {
              if (minEntry)
                if (
                  Number(minEntry[3]) > char &&
                  minEntry[1] === value[1] &&
                  minEntry[2] === value[2]
                )
                  char = Number(minEntry[3]);
            }

            changeValue((prevValue) => prevValue + char);
          }}
          onChange={(e) => {
            onChange?.({ formattedValue: newValue(), value, target: e.target });
          }}
        />
      </div>
    </>
  );
};

export default memo(InputEntry);
