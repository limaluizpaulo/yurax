import { useTranslation } from "react-i18next";
import CustomModal from "../../CustomModal";
import { useEffect, useLayoutEffect, useState } from "react";
import { Icon } from "@iconify/react";
import { twMerge } from "tailwind-merge";

const headers = ["option", "condition", "value"] as const;

const options = ["out-of-range", "in-range", "exceeded"] as const;

const conditions = [
  "default",
  "greater-than",
  "less-than",
  "equal-to"
] as const;
const conditionsIcon = {
  default: "bxs:question-mark",
  "greater-than": "ic:baseline-greater-than",
  "less-than": "ic:baseline-less-than",
  "equal-to": "material-symbols:equal"
};

const intialConfigOptions: TConfigOption[] = [
  {
    checked: false,
    option: "out-of-range",
    condition: "default",
    value: 0,
    color: "#E76161"
  },
  {
    checked: false,
    option: "in-range",
    condition: "default",
    value: 0,
    color: "#537188"
  },
  {
    checked: false,
    option: "exceeded",
    condition: "default",
    value: 0,
    color: "#47A992"
  }
];

type TConfigOption = {
  checked: boolean;
  option: (typeof options)[number];
  condition: (typeof conditions)[number];
  value: number;
  color: string;
};

interface IProps {
  currentOption: string;
  isOpen: boolean;
  currentDataConfig: TConfigOption[] | undefined;
  setIsOpen: (_value: boolean) => void;
  onSave: (_configOptions: TConfigOption[], _currentOption: string) => void;
}
const TableConfigModal = ({
  currentOption,
  isOpen,
  currentDataConfig,
  setIsOpen,
  onSave
}: IProps) => {
  const { t } = useTranslation();

  const [defaultConfigOptions] = useState([...intialConfigOptions]);

  console.log("Global UNCHANGED defaultConfigOptions: ", defaultConfigOptions);

  const [isNew, setIsNew] = useState(true);

  const [configOptions, setConfigOptions] =
    useState<TConfigOption[]>(defaultConfigOptions);

  useLayoutEffect(() => {
    setConfigOptions(currentDataConfig || defaultConfigOptions);
  }, [currentDataConfig]);

  useLayoutEffect(() => {});

  if (isNew && currentOption) {
    console.log(currentOption);
    console.log("Current defaultConfigOptions: ", defaultConfigOptions);
    setConfigOptions(defaultConfigOptions);
    setIsNew(false);
  }

  console.log("isNew, configOptions: ", isNew, configOptions);

  if (isNew && currentOption) return null;

  // console.log("Test");
  //
  // console.log("configOptions: ", configOptions);

  return (
    <CustomModal
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      title={t("common:config-table") + " - " + t(`forcast:${currentOption}`)}
    >
      <table>
        <thead>
          <tr>
            {headers.map((header) => (
              <th key={header}>{t(`common:${header}`)}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {configOptions.map(({ option, checked, condition, value }, index) => {
            return (
              <tr
                key={`${currentOption}-${option}`}
                className={twMerge(checked ? "" : "")}
              >
                <td
                  className={twMerge(
                    "flex justify-between items-center w-full",
                    !checked && "opacity-50"
                  )}
                >
                  <input
                    type="checkbox"
                    className="checkbox checkbox-sm"
                    name={option}
                    id={option}
                    checked={checked}
                    onChange={() => {
                      setConfigOptions((prev) =>
                        prev.map((option, optionIndex) => {
                          if (optionIndex === index) {
                            return {
                              ...option,
                              checked: !checked
                            };
                          }
                          return option;
                        })
                      );
                    }}
                  />
                  <label className="label" htmlFor={option}>
                    {t(`common:${option}`)}
                  </label>
                </td>
                <td className="px-4">
                  <select
                    className="select select-sm w-full bg-neutral"
                    name={option}
                    disabled={!checked}
                    value={condition}
                    onChange={(e) => {
                      const value = e.target
                        .value as (typeof conditions)[number];
                      setConfigOptions((prev) => {
                        const newConfigOptions = [...prev];

                        (newConfigOptions[index] as TConfigOption).condition =
                          value;

                        return newConfigOptions;
                      });
                    }}
                  >
                    <option value="default">{t("common:select")}</option>
                    {conditions.map((condition) => (
                      <option
                        key={`${currentOption}-${condition}`}
                        value={condition}
                      >
                        {/* <Icon icon={conditionsIcon[condition]} /> */}
                        {t(`common:${condition}`)}
                      </option>
                    ))}
                  </select>
                </td>
                <td key={`${currentOption}`} className="w-[10ch]">
                  <input
                    type="text"
                    disabled={!checked}
                    className="input input-sm bg-neutral w-full input-no-arrows"
                    placeholder={String(t("common:type"))}
                    value={value}
                    onChange={(e) => {
                      const value = Number(e.target.value);

                      if (isNaN(value)) return;

                      setConfigOptions((prev) => {
                        const newConfigOptions = [...prev];

                        (newConfigOptions[index] as TConfigOption).value =
                          value;

                        return newConfigOptions;
                      });
                    }}
                  />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button
        onClick={() => {
          setIsNew(true);
          onSave(configOptions, currentOption);
          setConfigOptions(defaultConfigOptions);
          setIsOpen(false);
        }}
        className="btn btn-primary self-end"
      >
        {t("common:save")}
      </button>
    </CustomModal>
  );
};

export default TableConfigModal;
