import CustomModal from "../../CustomModal";
import { useTranslation } from "react-i18next";
import moment from "moment";

const breaksTypes = {
  "7": "Banheiro",
  "102": "Almoço",
  "101": "Café"
};
interface IProps {
  data: {
    login: string;
    logout: string;
    extraHours: string;
    workBreaks?: {
      start: string;
      finish: string;
      type: string;
    }[];
    scalesBreak?: {
      start: string;
      finish: string;
      type: string;
    }[];
    breaks: {
      start: string;
      finish: string;
      type: string;
    }[];
  };
  agentName: string;
  accessKey?: "workBreaks" | "scalesBreak" | "breaks";
  isOpen: boolean;
  setIsOpen: (_value: boolean) => void;
}

const AgentScaleBreak = ({
  data,
  agentName,
  isOpen,
  setIsOpen,
  accessKey = "breaks"
}: IProps) => {
  const { t } = useTranslation(["common"]);

  console.log(data);

  return (
    <CustomModal
      title={t("break", { agentName })}
      isOpen={isOpen}
      setIsOpen={setIsOpen}
    >
      <h2 className="text-center text-2xl font-medium">{t(accessKey)}</h2>
      <table className="table table-zebra">
        <thead>
          <tr className="text-center">
            <th>{t("start")}</th>
            <th>{t("finish")}</th>
            <th>{t("break-type")}</th>
          </tr>
        </thead>
        <tbody>
          {(data?.[accessKey] as IProps["data"]["breaks"])?.map(
            (breaks, index) => (
              <tr key={index} className="text-center">
                <td>{moment.utc(breaks.start).format("HH:mm")}</td>
                <td>{moment.utc(breaks.finish).format("HH:mm")}</td>
                <td>{breaksTypes?.[breaks.type as "7"] ?? breaks.type}</td>
              </tr>
            )
          )}
        </tbody>
      </table>
    </CustomModal>
  );
};

export default AgentScaleBreak;
