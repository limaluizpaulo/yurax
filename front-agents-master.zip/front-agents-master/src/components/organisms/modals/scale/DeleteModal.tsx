import axios from "axios";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import CustomModal from "../../CustomModal";
import { ENV } from "@/constants/env.enum";
import { useSelector } from "react-redux";
import { AppState } from "@/stores";

const DeleteModal = ({
  isOpen,
  setIsOpen,
  scaleId
}: {
  isOpen: boolean;
  setIsOpen: () => void;
  scaleId: string;
}) => {
  const { t } = useTranslation();

  const auth = useSelector((state: AppState) => state.auth);

  const { replace } = useRouter();

  return (
    <CustomModal title={t("delete")} isOpen={isOpen} setIsOpen={setIsOpen}>
      <div className="flex flex-col justify-center">
        <p className="text-2xl form">
          {t("sure to delete", {
            ns: "scale"
          })}
        </p>
        <div className="flex gap-4 mt-4">
          <button
            className="btn btn-primary"
            onClick={() => {
              // console.log(`${ENV["API_URL"]}/scales/group/${scaleId}`);
              axios(`${ENV["API_URL"]}/scales/group/${scaleId}`, {
                method: "DELETE",
                headers: {
                  Authorization: `Bearer ${auth.token}`,
                  companyid: auth.user?.companyId
                }
              })
                .then(() => {
                  replace("/staffing/scalegroup");
                })
                .catch((error: any) => {
                  console.log(error);
                });
            }}
          >
            {t("delete")}
          </button>
        </div>
      </div>
    </CustomModal>
  );
};

export default DeleteModal;
