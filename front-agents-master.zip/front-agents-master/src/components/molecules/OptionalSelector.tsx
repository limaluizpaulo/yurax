import { useState } from "react";
import { useTranslation } from "react-i18next";

interface IProps {
  label: string;
  options: string[];
  onChange: (_value: string, _index: number) => void;
  defaultSelected?: number;
}

const OptionalSelector = ({
  label,
  options,
  onChange,
  defaultSelected = 0
}: IProps) => {
  const { t } = useTranslation();
  const [currentSelected, setCurrentSelected] = useState(defaultSelected);
  return (
    <div className="flex items-center rounded-btn p-0 h-12 bg-base-200 overflow-hidden">
      <span className="px-2 bg-neutral h-full flex items-center">{label}</span>
      <ul className="flex gap-2 px-2">
        {options.map((option, index) => {
          return (
            <li key={option}>
              <button
                onClick={() => {
                  if (currentSelected === index) return;
                  setCurrentSelected(index);
                  onChange(option, index);
                }}
                className={`badge hover:brightness-125 px-4 h-8 ${
                  index === currentSelected ? "badge-primary" : ""
                }`}
              >
                {t(option)}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default OptionalSelector;
