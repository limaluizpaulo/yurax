import { useTranslation } from 'react-i18next';

const weights = [
  {
    option: 'light weight',
    value: 0.5,
  },
  {
    option: 'medium weight',
    value: 1,
  },
  {
    option: 'heavy weight',
    value: 1.5,
  },
];

const SelectableWeights = ({
  currentWeight,
  setCurrentWeight,
}: {
  currentWeight: {
    option: string | number;
    value: number;
  };
  setCurrentWeight: (weight: {
    option: string | number;
    value: number;
  }) => void;
}) => {
  const { t } = useTranslation('forcast');

  return (
    <div className="flex flex-col justify-center gap-2">
      <h2 className="text-2xl font-medium">{t('weight')}</h2>
      <ul className="flex w-full gap-2">
        {weights.map(({ option, value }) => (
          <li key={option} className="flex items-center gap-2">
            <input
              checked={currentWeight.option === option}
              type="radio"
              className="radio radio-sm checked:radio-primary"
              name="weight"
              id={option}
              onChange={() => {
                setCurrentWeight({
                  option,
                  value,
                });
              }}
            />
            <label
              className="label cursor-pointer transition-colors hover:text-primary"
              htmlFor={option}
            >
              {t(option)}
            </label>
          </li>
        ))}
        <li className="ml-auto max-w-lg flex-1">
          <input
            type="range"
            min="-2.5"
            max="2.5"
            value={currentWeight.value}
            className={`range ${
              currentWeight.option === 'range' ? '' : 'opacity-50'
            }`}
            step="0.5"
            onChange={(e) => {
              setCurrentWeight({
                option: 'range',
                value: parseFloat(e.target.value),
              });
            }}
          />
          <ul className="flex w-full justify-between px-2 text-xs">
            {Array.from({ length: 11 }).map((_, index) => (
              <li
                key={`range-${index}`}
                className="relative mb-2 flex flex-col items-center justify-center gap-2"
              >
                <span>|</span>
                <span className="absolute top-full">{-2.5 + 0.5 * index}</span>
              </li>
            ))}
          </ul>
        </li>
      </ul>
    </div>
  );
};

export default SelectableWeights;
