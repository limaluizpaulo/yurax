/* eslint-disable import/no-extraneous-dependencies */
import { Icon } from '@iconify/react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';

const CopyToClipBoard = ({ text }: { text: string }) => {
  const { t } = useTranslation();
  const [hasCopiedText, setHasCopiedText] = useState(false);
  return (
    <div
      className="tooltip tooltip-top relative flex items-center"
      data-tip={t(
        hasCopiedText ? 'copied to your clipboard' : 'copy to clipboard'
      )}
    >
      <button
        type="button"
        onClick={() => {
          navigator.clipboard.writeText(text);
          setHasCopiedText(true);

          setTimeout(() => {
            setHasCopiedText(false);
          }, 1 * 1000);
        }}
        className="btn-ghost btn-xs btn-circle btn"
      >
        <Icon
          icon={
            hasCopiedText
              ? 'material-symbols:library-add-check-rounded'
              : 'material-symbols:copy-all'
          }
          className="h-4 w-4"
        />
      </button>
    </div>
  );
};

export default CopyToClipBoard;
