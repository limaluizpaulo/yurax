type TDisposition = {
  Disp_Id: number;
  Disposition_Desc: string;
  Disp_c: string;
};

interface IProps {
  dispositions: TDisposition[];
  onChangeSelection(
    _dispositionId: number,
    _actionType: "add" | "remove"
  ): void;
  selectedDispositions: number[];
}

const DispositionsList = ({
  dispositions,
  onChangeSelection,
  selectedDispositions
}: IProps) => {
  return (
    <>
      {dispositions?.map((disposition) => {
        return (
          <li key={disposition?.Disp_Id}>
            <div
              className="flex my-1 items-center disposition-item rounded-md px-4 gap-4 tooltip tooltip-top"
              data-tip={disposition?.Disposition_Desc}
            >
              <input
                type="checkbox"
                className="checkbox"
                name={disposition?.Disp_c}
                id={String(disposition?.Disp_Id)}
                checked={selectedDispositions.includes(disposition?.Disp_Id!)}
                onChange={(e) => {
                  onChangeSelection(
                    disposition?.Disp_Id,
                    e.target.checked ? "add" : "remove"
                  );
                }}
              />
              <label
                htmlFor={String(disposition?.Disp_Id)}
                className="label label-text"
              >
                {disposition?.Disp_c} - {disposition?.Disposition_Desc}
                {disposition?.Disp_Id}
              </label>
            </div>
          </li>
        );
      })}
    </>
  );
};

export default DispositionsList;
