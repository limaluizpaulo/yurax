import { Icon } from "@iconify/react";

type TRealTime = {
  allAgentsLoggeds: number;
  allAgentsInCall: number;
  allAgentIdle: number;
  allAgentNotReady: number;
  allAgentOthers: number;
  inHold: number;
  inWrap: number;
};

const icons = {
  allAgentsLoggeds: "mdi:user",
  allAgentsInCall: "ic:baseline-phone",
  allAgentIdle: "mdi:phone-clock",
  allAgentNotReady: "mdi:phone-off",
  allAgentOthers: "ic:baseline-phone",
  inHold: "mdi:phone-paused",
  inWrap: "mdi:phone-plus"
};

const AgentCard = ({
  label,
  data,
  objectKey,
  big
}: {
  label: string;
  big: TRealTime[];
  objectKey: keyof TRealTime;
  data: string;
}) => {
  return (
    <div
      className={`shadow-md relative rounded-btn flex items-center justify-between p-4 hover:brightness-125 bg-base-200 ${
        big.includes(objectKey as any) ? "row-span-2" : ""
      }`}
    >
      <Icon icon={icons[objectKey]} className="text-6xl" />
      <div className="flex flex-col items-end">
        <h3 className="text-4xl font-bold">{data}</h3>
        <span>{label}</span>
      </div>
    </div>
  );
};

export default AgentCard;
