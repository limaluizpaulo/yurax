import { Menu } from "@headlessui/react"; // eslint-disable-line import/no-extraneous-dependencies
import { Icon } from "@iconify/react"; // eslint-disable-line import/no-extraneous-dependencies
import Link from "next/link";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
// eslint-disable-line import/no-extraneous-dependencies

const languages = [
  {
    name: "Português",
    locale: "pt-BR",
    icon: "twemoji:flag-brazil"
  },
  {
    name: "English",
    locale: "en",
    icon: "twemoji:flag-united-states"
  },
  {
    name: "Español",
    locale: "es",
    icon: "twemoji:flag-spain"
  }
];

const LanguagesMenu = () => {
  const { pathname, locale: currentLocale, query } = useRouter();
  const { t } = useTranslation(["common"]);

  return (
    <div className="dropdown-bottom dropdown">
      <Menu>
        <div
          className=" tooltip tooltip-bottom"
          data-tip={t("change-language")}
        >
          <Menu.Button className="btn-ghost btn-circle btn">
            <Icon className="text-2xl" icon="bx:world" />
          </Menu.Button>
        </div>
        <Menu.Items className="dropdown-content menu rounded-box right-0 mt-2 bg-base-200 p-2 shadow-lg">
          {languages.map(({ locale, icon, name }) => (
            <li key={name}>
              <Menu.Item>
                <Link
                  className={`${
                    currentLocale === locale
                      ? "bg-primary text-neutral-content"
                      : ""
                  }`}
                  href={{ pathname, query }}
                  locale={locale}
                >
                  <Icon icon={icon} />
                  <span>{name}</span>
                </Link>
              </Menu.Item>
            </li>
          ))}
        </Menu.Items>
      </Menu>
    </div>
  );
};

export default LanguagesMenu;
