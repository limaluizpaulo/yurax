/* eslint-disable import/no-extraneous-dependencies */
// eslint-disable-line import/no-extraneous-dependencies
// eslint-disable-line import/no-extraneous-dependencies
import { logout } from "@/stores/authSlice";
import { Icon } from "@iconify/react";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/router";
import { useState } from "react";
import { useTranslation } from "react-i18next"; // eslint-disable-line import/no-extraneous-dependencies
import { useDispatch } from "react-redux";

const links = [
  // {
  //   name: "users",
  //   href: "/users",
  //   icon: "majesticons:users",
  //   current: true,
  //   variant: "none"
  // },
  // {
  //   name: "config",
  //   href: "/settings",
  //   icon: "ph:gear-six-fill",
  //   current: false,
  //   variant: "none"
  // },
  {
    name: "logout",
    href: "/logout",
    icon: "tabler:logout",
    current: false,
    variant: "bg-error"
  }
];

const HeaderMenu = () => {
  const { t } = useTranslation("common");
  const dispatch = useDispatch();

  const [isOpen, setIsOpen] = useState(false);

  const overlayProps = {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 }
  };

  const sidebarProps = {
    initial: { x: "100%" },
    animate: { x: 0 },
    exit: { x: "100%" },
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 20,
      duration: 0.3
    }
  };

  return (
    <>
      <button className="btn" onClick={() => setIsOpen(true)}>
        <Icon icon="material-symbols:menu-open-rounded" className="h-6 w-6" />
      </button>
      <AnimatePresence mode="wait">
        {isOpen && (
          <motion.div className="absolute top-0 left-0 z-20 flex h-screen w-screen justify-end">
            <motion.span
              {...overlayProps}
              className="absolute top-0 left-0 z-20 h-full w-full bg-black/60"
              onClick={() => {
                setIsOpen(false);
              }}
            />
            <motion.div
              {...sidebarProps}
              className="relative z-30 flex w-72 flex-col gap-2 bg-neutral p-2"
            >
              <button
                className="btn ml-auto"
                onClick={() => {
                  setIsOpen(false);
                }}
              >
                <Icon
                  icon="material-symbols:menu-open-rounded"
                  className="h-6 w-6"
                  flip="horizontal"
                />
              </button>
              <ul className="menu rounded-btn bg-base-200">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className=""
                      onClick={(e) => {
                        if (link.name === "logout") {
                          e.preventDefault();
                          dispatch(logout());
                        }

                        setIsOpen(false);
                      }}
                    >
                      <Icon icon={link.icon} />
                      <span>{t(link.name)}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default HeaderMenu;
