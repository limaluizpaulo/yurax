/* eslint-disable no-nested-ternary */
import { format, getDaysInMonth } from 'date-fns';
// import { useRouter } from "next/router";
import type { Dispatch, SetStateAction } from 'react';
import { useEffect, useMemo, useRef } from 'react';
import { useTranslation } from 'react-i18next';

const SelectableDays = ({
  currentDays,
  setCurrentDays,
}: {
  currentDays: [number, number] | [number];
  setCurrentDays: Dispatch<SetStateAction<[number, number] | [number]>>;
}) => {
  const daysContainerRef = useRef<HTMLUListElement>(null);

  const days = useMemo(() => {
    return Array.from({ length: getDaysInMonth(new Date()) })
      .fill(0)
      .map((_, index) => index + 1);
  }, []);

  const { t } = useTranslation('common');

  useEffect(() => {
    if (daysContainerRef.current) {
      const day = daysContainerRef.current.querySelector(
        `[data-day="${currentDays}"]`
      );
      if (day) {
        day.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, []);

  return (
    <div>
      <ul
        ref={daysContainerRef}
        className="flex h-full gap-4 overflow-x-auto py-2"
      >
        {days.map((day, index) => (
          <li key={index}>
            <button
              onClick={() => {
                if (currentDays.length === 2) {
                  setCurrentDays([day]);
                } else if (currentDays.length === 1) {
                  if (currentDays[0] < day) {
                    setCurrentDays([currentDays[0], day]);
                  } else {
                    setCurrentDays([day, currentDays[0]]);
                  }
                } else {
                  setCurrentDays([day, day]);
                }
              }}
              data-day={day}
              className={`
                  rounded-btn flex h-24 w-20 flex-col
                  items-center justify-center gap-2 bg-neutral p-4 text-neutral-content transition-all 
                  hover:bg-primary/50 active:scale-95 
                  ${
                    currentDays[0] === day || currentDays[1] === day
                      ? 'bg-primary'
                      : currentDays.length === 2 &&
                        day > currentDays[0] &&
                        day < currentDays[1]
                      ? 'bg-primary/50'
                      : ''
                  }
                `}
            >
              <span className="text-2xl">{day}</span>
              <span>
                {t(
                  `daysOfWeek.${format(
                    new Date(2023, 2, day),
                    'EE'
                  ).toLowerCase()}`
                )}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SelectableDays;
