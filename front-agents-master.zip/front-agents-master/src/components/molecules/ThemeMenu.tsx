import { Menu } from "@headlessui/react"; // eslint-disable-line import/no-extraneous-dependencies
import { Icon } from "@iconify/react"; // eslint-disable-line import/no-extraneous-dependencies
import { memo } from "react";
import { useDispatch, useSelector } from "react-redux";

import type { AppState } from "@/stores";
import { changeTheme } from "@/stores/settingsSlice";
import { useTranslation } from "react-i18next";

const themes = [
  {
    name: "dark",
    id: "dark",
    icon: "ic:round-dark-mode"
  },
  {
    name: "light",
    id: "cmk",
    icon: "ic:round-light-mode"
  }
] as const;

const ThemeMenu = () => {
  const dispatch = useDispatch();
  const settings = useSelector((state: AppState) => state.settings);
  const { t } = useTranslation(["common"]);

  return (
    <div className="dropdown-bottom dropdown">
      <Menu>
        <div className=" tooltip tooltip-bottom" data-tip={t("change-theme")}>
          <Menu.Button className="btn-ghost btn-circle btn">
            <Icon className="text-2xl" icon="icon-park-solid:dark-mode" />
          </Menu.Button>
        </div>
        <Menu.Items className="dropdown-content menu rounded-box right-0 mt-2 bg-base-200 p-2 shadow-lg">
          {themes.map(({ id, icon, name }) => (
            <li key={id}>
              <Menu.Item>
                <button
                  className={`${
                    id === settings.theme
                      ? "bg-primary text-neutral-content"
                      : ""
                  }`}
                  onClick={() => {
                    document
                      .querySelector("body")
                      ?.setAttribute("data-theme", id);
                    dispatch(changeTheme(id as "dark" | "cmk"));
                  }}
                >
                  <Icon icon={icon} />
                  <span>{t(name)}</span>
                </button>
              </Menu.Item>
            </li>
          ))}
        </Menu.Items>
      </Menu>
    </div>
  );
};

export default memo(ThemeMenu);
