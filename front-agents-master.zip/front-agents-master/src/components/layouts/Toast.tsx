import { useSelector } from 'react-redux';

import type { AppState } from '@/stores';

const Toast = () => {
  const toast = useSelector((state: AppState) => state.toast);

  console.log(toast);
  return (
    <ul className="toast-stop toast-start toast">
      {toast.map(({ message, createdAt, id, variant }) => (
        <li key={id} className={`alert ${variant} text-white`}>
          <div className="toast-item-icon">
            <i className="fas fa-check"></i>
          </div>
          <div className="toast-item-content">
            <h3 className="text-xl">{message}</h3>
            <span className="text-xs">{createdAt}</span>
          </div>
        </li>
      ))}
    </ul>
  );
};

export default Toast;
