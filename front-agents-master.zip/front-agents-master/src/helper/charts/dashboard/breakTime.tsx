import { merge } from "lodash";
import { genericChartsOptions, moment } from "..";

export interface IBreakTime {
  total_all_brks_time_scaled: number | null;
  total_all_brks_time_worked: number | null;
}

export const BreakTimeDataToChart = (data: IBreakTime, agent: { firstName: string }) => {
  return merge(
    genericChartsOptions({
      id: "break-time"
    }),
    {
      options: {
        xaxis: {
          categories: [agent?.firstName ?? ""],
          labels: {
            style: {
              colors: ["var(--tw-ring-color)"]
            }
          }
        },
        dataLabels: {
          formatter(val: any) {
            return moment
              .duration(val ?? 2000, "millisecond")
              .format("hh[h]mm[m]");
          }
        },
        tooltip: {
          y: {
            formatter(val: any) {
              return moment
                .duration(val ?? 2000, "millisecond")
                .format("hh[h]mm[m]ss[s]");
            }
          }
        }
      },
      series: [
        {
          name: "Projetado",
          data: [data?.total_all_brks_time_scaled ?? 0]
        },
        {
          name: "Efetivo",
          data: [data?.total_all_brks_time_worked ?? 2000]
        }
      ]
    }
  );
};
