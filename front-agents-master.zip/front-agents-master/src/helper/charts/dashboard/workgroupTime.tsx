import { merge } from "lodash";
import { genericChartsOptions, moment } from "..";

export const AgentExtraHoursToChart = (data: number, agent: any) => {
  return merge(
    genericChartsOptions({
      id: "workgroup-extra-hours"
    }),
    {
      options: {
        chart: {
          type: "donut"
        },
        labels: [agent?.firstName ?? ""],
        dataLabels: {
          formatter: (_: any, opts: any) => {
            const currentSeries = opts.w.globals.series[opts.seriesIndex];
            return moment
              .duration(currentSeries, "hours")
              .format("hh[h]mm[min]");
          }
        }
      },
      series: [data]
    }
  );
};
