import { merge } from "lodash";
import { genericChartsOptions } from "..";

export const agentAdherencesToChart = (data: number | null) => {
  return merge(
    genericChartsOptions({
      id: "adherences",
      foreColor: "var(--tw-ring-color)"
    }),
    {
      options: {
        chart: {
          type: "radialBar",
          offsetY: -20,
          sparkline: {
            enabled: true
          }
        },
        plotOptions: {
          radialBar: {
            startAngle: -90,
            endAngle: 90,
            track: {
              background: "var(--tw-ring-color)",
              strokeWidth: "100%",
              margin: 8, // margin is in pixels
              opacity: 0.5
            },
            dataLabels: {
              name: {
                show: true,
                fontSize: "16px",
                color: "var(--tw-ring-color)",
                offsetY: 10
              },
              value: {
                offsetY: -20,
                fontSize: "22px"
              },
              style: {
                colors: ["var(--tw-ring-color)"]
              }
            }
          }
        },
        labels: [""]
      },
      series: [data]
    }
  );
};
