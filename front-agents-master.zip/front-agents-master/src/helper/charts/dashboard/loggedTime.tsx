import { merge } from "lodash";
import { genericChartsOptions, moment } from "..";

export interface ILoggedTime {
  total_worked_time: number | null;
  total_scaled_time: number | null;
}

export const LoggedTimeDataToChart = (data: ILoggedTime, agent: { firstName: string }) => {
  return merge(
    genericChartsOptions({
      id: "logged-time"
    }),
    {
      options: {
        xaxis: {
          categories: [agent?.firstName ?? ""],
          labels: {
            style: {
              colors: ["var(--tw-ring-color)"]
            }
          }
        },
        dataLabels: {
          formatter(val: any) {
            return moment
              .duration(val ?? 2000, "millisecond")
              .format("hh[h]mm[m]");
          }
        },
        tooltip: {
          y: {
            formatter(val: any) {
              return moment
                .duration(val ?? 2000, "millisecond")
                .format("hh[h]mm[m]ss[s]");
            }
          }
        }
      },
      series: [
        {
          name: "Projetado",
          data: [data?.total_scaled_time ?? 0]
        },
        {
          name: "Efetivo",
          data: [data?.total_worked_time ?? 0]
        }
      ]
    }
  );
};
