export const customReportsChart = (data: any[], labels: string[]) => {
  return {
    options: {
      chart: {
        foreColor: "var(--nc)",
        type: "line",
        height: 350,
        toolbar: {
          show: false
        }
      },
      colors: ["#A5D7E8", "#576CBC", "#19376D", "#0B2447"],
      grid: {
        show: false
      },
      legend: {
        position: "top"
      },
      // dataLabels: {
      //   enabled: true,
      //   formatter: (val: any) => {
      //     return String(val?.toFixed(2));
      //   },
      //   enabledOnSeries: [1]
      // },
      yaxis: {
        labels: {
          style: {
            colors: ["var(--tw-ring-color)"]
          },
          formatter: (val: any) => {
            if (val !== undefined) return String(val?.toFixed(0));
            return val;
          }
        }
      },
      xaxis: {
        labels: {
          style: {
            colors: "var(--tw-ring-color)"
          }
        }
      },
      labels
    },
    series: data
  };
};
