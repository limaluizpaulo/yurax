import moment from "moment";
import momentDurationFormatSetup from "moment-duration-format";
import { forecastStatisticsToChart } from "./forecast/statistics";
import { LoggedTimeDataToChart } from "./dashboard/loggedTime";
import { AgentExtraHoursToChart } from "./dashboard/workgroupTime";
import { agentAdherencesToChart } from "./dashboard/adherences";
import { totalAbsenteismToChart } from "./dashboard/totalAbsenteeism";
import { forecastReportsToChart } from "./forecast/reports";
import { forecastStaffingToChart } from "./forecast/staffing";

momentDurationFormatSetup(moment as any);

export const genericChartsOptions = ({
  foreColor = "var(--nc)",
  id = "any"
}) => ({
  options: {
    chart: {
      id,
      foreColor,
      toolbar: {
        show: false
      }
    },
    plotOptions: {
      bar: {
        borderRadius: 4,
        borderRadiusApplication: "around"
      }
    },
    colors: ["#1ab7ea", "#0084ff"],
    grid: {
      show: false
    },
    legend: {
      position: "top"
    },
    xaxis: {
      labels: {
        style: {
          colors: ["var(--tw-ring-color)"]
        }
      }
    },
    dataLabels: {
      enabled: true
    },
    tooltip: {
      x: {}
    },
    yaxis: {
      show: false
    }
  }
});

export {
  forecastStatisticsToChart,
  LoggedTimeDataToChart,
  moment,
  totalAbsenteismToChart,
  AgentExtraHoursToChart,
  agentAdherencesToChart,
  forecastReportsToChart,
  forecastStaffingToChart
};
