import { ColumnDef, createColumnHelper } from "@tanstack/react-table";
import { t } from "i18next";
import moment from "moment";
import momentDurationFormatSetup from "moment-duration-format";

type IsValidKey<T, K extends keyof T> = K extends string ? K : never;
type ArrayOfUniqueKeys<T> = Array<IsValidKey<T, keyof T>>;

momentDurationFormatSetup(moment as any);

const GenericDataToTable = <TypeDTO extends unknown>(
  defaultData: TypeDTO[] = [],
  accessKeys: Partial<Record<keyof TypeDTO, any>> = {} as any,
  defaultColumns: Partial<keyof TypeDTO>[] = [],
  translation: (key: string) => string = t,
  tableConfig: Record<keyof Partial<any>, "time" | "date" | "datetime" | "percentage">,
  hiddenColumns: ArrayOfUniqueKeys<TypeDTO>,
  translationKey: "agent" | "common" = "common"
): {
  defaultData: TypeDTO[];
  columns: ColumnDef<TypeDTO, unknown>[];
} => {
  const columnHelper = createColumnHelper<TypeDTO>();

  // Verify and add a key that is an object to an array if not treated by accessKey
  const KeysThatAreObjects = Object.entries(defaultData?.[0] ?? []).reduce(
    (acc, [key, value]) => {
      if (hiddenColumns.includes(key as any)) return acc;
      if (typeof value === "object" && !Object.keys(accessKeys).includes(key)) {
        acc.push(key as keyof TypeDTO);
      }
      return acc;
    },
    [] as (keyof TypeDTO)[]
  );

  // Using tanstack assist creator to create table columns
  const columns =
    (defaultColumns.length > 0
      ? defaultColumns
      : (Object.keys(defaultData?.[0] ?? []) as (keyof TypeDTO)[])
    )
      .filter((key) => !hiddenColumns.includes(key as any))
      .map((key: any) => {
        const header = translation(`${translationKey}:${String(key)}`);
        if (KeysThatAreObjects.includes(key as keyof TypeDTO)) {
          if (
            (defaultData?.[0]?.[key as keyof TypeDTO] as Array<string>)?.length
          ) {
            key = `${String(key)}.length`;
          }
        }

        return columnHelper.accessor(key as any, {
          header,
          cell: (info) => {
            if (tableConfig[key as keyof typeof tableConfig] === "time") {
              return moment
                .duration(info.getValue() as number, "millisecond")
                .format("HH[h]mm[m]ss[s]");
            }

            if (tableConfig[key as keyof typeof tableConfig] === "date") {
              return moment(info.getValue() as Date).format("DD/MM/YYYY");
            }

            if (tableConfig[key as keyof typeof tableConfig] === "datetime") {
              return moment.utc(info.getValue() as Date).format("DD/MM/YYYY, HH:mm");
            }

            if (tableConfig[key as keyof typeof tableConfig] === "percentage") {
              return `${info.getValue()}%`;
            }
            return info.getValue();
          }
        });
      }) ?? [];

  return { defaultData, columns };
};

export default GenericDataToTable;
