import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// This function can be marked `async` if using `await` inside
export function middleware(request: NextRequest) {
  let auth = JSON?.parse(request.cookies.get('auth')?.value ?? "{}");

  // console.log(request.url);
  // console.log(auth);

  const { pathname } = request.nextUrl;
  const PUBLIC_FILE = /^\/?(?:[^/]+\/)*[^/]+\.[^/]+$/;

  if (
    pathname.startsWith("/_next") || // exclude Next.js internals
    pathname.startsWith("/api") || //  exclude all API routes
    pathname.startsWith("/static") || // exclude static files
    // pathname.startsWith(`/${auth.application}`) || // exclude all redirects routes from applications
    // pathname.startsWith(`/applications`) ||
    PUBLIC_FILE.test(pathname) // exclude all files in the public folder
  )
    return NextResponse.next();

  // if (!auth.user && request.url !== "/login") return NextResponse.redirect(new URL('/login', request.url))

  // if (auth?.application) {
  //   return NextResponse.redirect(new URL(`/${auth.application}${pathname}`, request.url))
  // } else {
  //   // console.log("There's no application ")
  //   return NextResponse.redirect(new URL('/applications', request.url))
  // }
  return NextResponse.next();
}
export const config = {
  matcher: [
    '/((?!api|_next/static|favicon.ico|login|mockServiceWorker.js).*)',
  ]
}
// See "Matching Paths" below to learn more
// export const config = {
//   matcher: '/:path*',
// }