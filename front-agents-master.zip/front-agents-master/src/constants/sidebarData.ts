import scaledAndWorkedTimes from "@/pages/scaled-and-worked-times";

const defaultSidebar = [
  {
    label: "Home",
    icon: "ph:house-fill",
    href: "/",
    submenus: []
  },
  {
    label: "scales",
    icon: "majesticons:table-plus-line",
    href: "/scales",
    submenus: []
  },
  {
    label: "real-worked-times",
    icon: "ri:time-fill",
    href: "/real-worked-times",
    submenus: []
  },
  {
    label: "adherence",
    icon: "mdi:chart-line",
    href: "/general",
    submenus: []
  },
  // {
  //   label: "scaled-and-worked-times",
  //   icon: "ri:time-fill",
  //   href: "/scaled-and-worked-times",
  //   submenus: []
  // }
]

export const getSidebar = (_currentSidebar: string) => {

  return defaultSidebar;
}