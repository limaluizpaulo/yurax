export const DEFAULT_CONFIG_OPTIONS = [
  {
    checked: false,
    option: "out-of-range",
    condition: "default",
    value: 0,
    color: "#E76161"
  },
  {
    checked: false,
    option: "in-range",
    condition: "default",
    value: 0,
    color: "#537188"
  },
  {
    checked: false,
    option: "exceeded",
    condition: "default",
    value: 0,
    color: "#47A992"
  }
];

