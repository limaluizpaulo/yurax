export const ENV = {
  API_URL: process.env.NEXT_PUBLIC_API_URL,
  ENVIRONMENT: process.env.NEXT_PUBLIC_NODE_ENV,
  HTTPS: process.env.HTTPS,
  HOST: process.env.NEXT_PUBLIC_HOST,
}