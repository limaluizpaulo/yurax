export const AppConfig = {
  site_name: 'Comuniki Me - Intelligence',
  title: 'Comuniki Me - Intelligence',
  description:
    'O melhor gerenciador para sua empresa, trazendo com si a inteligência necessária para o forcast entre outras funcionalidades',
  locale: 'pt-BR',
};
