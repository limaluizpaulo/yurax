/* eslint-disable no-param-reassign */
// @ts-nocheck
import type {
  SliceCaseReducers,
  ValidateSliceCaseReducers,
} from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit'; // eslint-disable-line import/no-extraneous-dependencies
import { HYDRATE } from 'next-redux-wrapper'; // eslint-disable-line import/no-extraneous-dependencies
import { v4 as uuidv4 } from 'uuid';

import type { AppState } from '.';

// Type for our state
export interface IToastState {
  id: number;
  variant: 'alert-success' | 'alert-error' | 'alert-warning' | 'alert-info';
  message: string;
  createdAt: string;
}

// Initial state
const initialState: IToastState[] = [
  {
    id: 1,
    variant: 'alert-success',
    message: 'Sucesso um',
    createdAt: '2021-08-01T00:00:00.000Z',
  },
  {
    id: 2,
    variant: 'alert-success',
    message: 'Sucesso dois',
    createdAt: '2021-08-01T00:00:00.000Z',
  },
];
export interface IReducers
  extends ValidateSliceCaseReducers<
    IToastState,
    SliceCaseReducers<IToastState>
  > {
  fire: (state: IToastState[], { payload: any }) => void;
  extraReducers: {
    [HYDRATE]: (state: IToastState, action: any) => IToastState;
  };
}

const reducers: IReducers = {
  fire: (state, { payload }) => {
    state = [
      ...state,
      {
        ...payload,
        id: uuidv4(),
        createdAt: new Date().toISOString(),
      },
    ];
  },
  extraReducers: {
    [HYDRATE]: (state: IToastState, action: any) => {
      return {
        ...state,
        ...action.payload.modal,
      };
    },
  },
};

// Actual Slice
export const toastSlice = createSlice({
  name: 'toast',
  initialState,
  reducers,
});

export const { add } = toastSlice.actions;

export const toasts = (state: AppState) => state.toast;

// export const isModalOpen = (state: AppState) => state.modal.isOpen;

export default toastSlice.reducer;
