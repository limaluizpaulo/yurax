import type { Action, ThunkAction } from '@reduxjs/toolkit';
import { configureStore } from '@reduxjs/toolkit'; // eslint-disable-line import/no-extraneous-dependencies
import { createWrapper } from 'next-redux-wrapper'; // eslint-disable-line import/no-extraneous-dependencies

import { authSlice } from './authSlice';
import { notificationsSlice } from './notificationsSlice';
import { settingsSlice } from './settingsSlice';
import { toastSlice } from './toastSlice';

const makeStore = () =>
  configureStore({
    reducer: {
      [notificationsSlice.name]: notificationsSlice.reducer,
      [authSlice.name]: authSlice.reducer,
      [toastSlice.name]: toastSlice.reducer,
      [settingsSlice.name]: settingsSlice.reducer,
    },
    devTools: true,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({
        thunk: true,
        immutableCheck: false,
        serializableCheck: false,
      }),
  });

export type AppStore = ReturnType<typeof makeStore>;
export type AppState = ReturnType<AppStore['getState']>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  AppState,
  unknown,
  Action
>;

export const wrapper = createWrapper<AppStore>(makeStore);
