// @ts-nocheck
/* eslint-disable no-param-reassign */
import { SliceCaseReducers, ValidateSliceCaseReducers } from "@reduxjs/toolkit";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { deleteCookie, getCookie, setCookie } from "cookies-next"; // eslint-disable-line import/no-extraneous-dependencies

// eslint-disable-line import/no-extraneous-dependencies
import type { AppState } from ".";
import { ENV } from "@/constants/env.enum";

// Type for our state
export interface AuthState {
  token: string | undefined;
  state: "none" | "error" | "logged";
  firstLogin?: boolean;
  user:
    | {
        id: string;
        _id: string;
        firstName: string;
        lastName: string;
        image?: string;
        email: string;
        avatar: string;
        role: string;
        tenant: string;
        companyId: string;
        databaseId?: string;
      }
    | undefined;
}

let dataFromCookies: any;

try {
  dataFromCookies = JSON.parse(getCookie("auth"));
} catch (error) {
  // console.log('Erro ao pegar os cookies: ', error);
}

// Initial state
const initialState: AuthState = dataFromCookies || {
  token: undefined,
  state: "none",
  user: undefined
};

export interface IReducers
  extends ValidateSliceCaseReducers<AuthState, SliceCaseReducers<AuthState>> {
  logout: () => void;
  resetLoginAttempt: () => void;
}

export const login: any = createAsyncThunk(
  "auth/login",
  async ({ rejectWithValue, ...payload }) => {
    try {
      const res = await axios({
        method: "post",
        url: `${ENV["API_URL"]}/login`,
        data: {
          email: payload.email,
          password: payload.password
        }
      });

      // console.log(res);

      const { data } = res;

      console.log("Getting the response from the login: ", data);

      if (res.status === 401 || res.status === 404)
        throw new Error(res.message);

      if (res.status === 200 || res.status === 201) {
        setCookie(
          "auth",
          JSON.stringify({
            token: data.token,
            user: data.resp,
          })
        );
      }
      return {
        token: data.token,
        user: data.sessionDetails,
        state: "logged"
      };
    } catch (error) {
      rejectWithValue(error.message);
      // throw new Error(error.message);
      // return {
      //   token: undefined,
      //   user: undefined,
      //   state: "error"
      // };
    }
  }
);

const reducers: IReducers = {
  logout: (state) => {
    console.log("Called the logout reducer");
    state.token = undefined;
    state.user = undefined;
    state.state = "none";
    deleteCookie("auth");
    // return { ...state };
  },
  resetLoginAttempt: (state) => {
    state.state = "none";
  }
};

// Actual Slice
export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers,
  extraReducers: {
    [login.fulfilled]: (state, action) => {
      console.log(state, action);
      state.token = action.payload.token;
      state.state = "logged";
      state.firstLogin = action.payload?.firstLogin ?? false;
      state.user = action.payload.user;
    },
    [login.rejected]: (state) => {
      console.log("I got here");
      state.token = undefined;
      state.state = "error";
      state.user = undefined;
    }
  }
});

export const { logout, resetLoginAttempt } = authSlice.actions;

export const auth = (state: AppState) => state.auth;

export default authSlice.reducer;
