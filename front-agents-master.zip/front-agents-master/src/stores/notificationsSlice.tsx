/* eslint-disable no-param-reassign */
import type {
  SliceCaseReducers,
  ValidateSliceCaseReducers,
} from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit'; // eslint-disable-line import/no-extraneous-dependencies

import type { AppState } from '.';

// Type for our state
export interface INotificationsState {
  items: {
    id: number;
    title: string;
    description: string;
    createdAt: string;
  }[];
}

// Initial state
const initialState: INotificationsState = {
  items: [
    {
      id: 1,
      title: 'Notificação 1',
      description: 'Descrição da notificação 1',
      createdAt: '2021-08-01T00:00:00.000Z',
    },
    {
      id: 2,
      title: 'Notificação 2',
      description: 'Descrição da notificação 2',
      createdAt: '2021-08-01T00:00:00.000Z',
    },
  ],
};
export interface IReducers
  extends ValidateSliceCaseReducers<
    INotificationsState,
    SliceCaseReducers<INotificationsState>
  > {
  add: (
    state: INotificationsState,
    { payload }: { payload: INotificationsState['items'][0] }
  ) => void;
}

const reducers: IReducers = {
  add: (state, { payload }) => {
    state.items = [...state.items, payload];
  },
};

// Actual Slice
export const notificationsSlice = createSlice({
  name: 'notifications',
  initialState,
  reducers,
  extraReducers: {},
});

export const { add } = notificationsSlice.actions;

export const selectNotifications = (state: AppState) =>
  state.notifications.items;

// export const isModalOpen = (state: AppState) => state.modal.isOpen;

export default notificationsSlice.reducer;
