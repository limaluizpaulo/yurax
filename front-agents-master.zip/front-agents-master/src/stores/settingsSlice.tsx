import type {
  SliceCaseReducers,
  ValidateSliceCaseReducers
} from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";
import moment from "moment";

import { loadState, saveState } from "@/utils/BrowserStorage";

import type { AppState } from ".";
import { getCookie } from "cookies-next";

export interface ISettingsState {
  theme: "cmk" | "dark" | undefined;
  adherence: {
    startDate: Date;
    endDate: Date;
  };
}

let dataFromCookies: any;

try {
  dataFromCookies = JSON.parse(getCookie("auth") as any);
} catch (error) {
  // console.log('Erro ao pegar os cookies: ', error);
}

const initialState: ISettingsState = {
  theme: undefined,
  adherence: {
    startDate: moment().subtract(4, "week").toDate(),
    endDate: moment().toDate()
  },
  ...loadState()
};
export interface IReducers
  extends ValidateSliceCaseReducers<
    ISettingsState,
    SliceCaseReducers<ISettingsState>
  > {
  changeTheme: (
    _state: ISettingsState,
    _payload: { payload: "cmk" | "dark"; type: string }
  ) => void;
  setDate: (
    _state: ISettingsState,
    _payload: { payload: { startDate: Date; endDate: Date } }
  ) => void;
}

const reducers: IReducers = {
  changeTheme: (state, { payload }) => {
    const newState = {
      ...state,
      theme: payload
    };
    saveState({ theme: payload });
    return newState;
  },
  setDate: (state, { payload }) => {
    return {
      ...state,
      adherence: {
        ...state.adherence,
        ...payload
      }
    };
  }
};

// Actual Slice
export const settingsSlice = createSlice({
  name: "settings",
  initialState,
  reducers,
  extraReducers: {}
});

export const { changeTheme, setDate, setDataTableConfig } =
  settingsSlice.actions;
export const settings = (state: AppState) => state.settings;

export default settingsSlice.reducer;
