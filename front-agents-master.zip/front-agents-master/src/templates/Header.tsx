import Image from "next/image";
import Link from "next/link";
import { useTranslation } from "next-i18next"; // eslint-disable-line import/no-extraneous-dependencies
import { useSelector } from "react-redux";

import Logo from "@/components/atom/Icons/Logo";
import LogoCmk from "@/components/atom/Icons/LogoCmk";
import HeaderMenu from "@/components/molecules/HeaderMenu";
import LanguagesMenu from "@/components/molecules/LanguagesMenu";
import ThemeMenu from "@/components/molecules/ThemeMenu";
import Notifications from "@/components/organisms/Notifications";
import { auth } from "@/stores/authSlice";

const Header = () => {
  const { user } = useSelector(auth);
  const { t } = useTranslation("common");

  return (
    <header className="relative z-20 flex h-16 translate-x-0 items-center justify-between py-2 px-4 shadow-md">
      <Link
        href="/"
        className="flex h-full items-center gap-2 text-2xl font-bold uppercase"
      >
        <Logo className="w-48 text-sm text-primary" />
      </Link>
      <div className="flex items-center gap-4">
        {/* <Notifications /> */}
        <LanguagesMenu />
        <ThemeMenu />
        <Link className="flex items-center gap-2" href={`/profile/`}>
          <div className="relative h-8 w-8 overflow-hidden rounded-full outline outline-2 outline-primary">
            <Image
              src={user?.image ?? "/images/user-default.webp"}
              alt="user image"
              fill
            />
          </div>
          <span>
            {t("greetings")}, {user?.firstName}!
          </span>
        </Link>
        <HeaderMenu />
      </div>
    </header>
  );
};

export default Header;
