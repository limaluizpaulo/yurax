/* eslint-disable no-param-reassign */
import { getSidebar } from "@/constants/sidebarData";
import { AppState } from "@/stores";
import { Icon } from "@iconify/react"; // eslint-disable-line import/no-extraneous-dependencies
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/router";
import { memo, useCallback, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
import { twMerge } from "tailwind-merge"; // eslint-disable-line import/no-extraneous-dependencies
import { sidebarMotions } from "./sidebarMotions";

const Sidebar = ({
  isOpen,
  setIsOpen
}: {
  isOpen: boolean;
  setIsOpen(): void;
}) => {
  const settings = useSelector((state: AppState) => state.settings);
  const [currentOpenMenu, setCurrentOpenMenu] = useState<null | number>(null);
  const items = getSidebar("");
  const { pathname } = useRouter();
  const defaultPos = items.findIndex((item) => pathname === item.href);
  const [currentHoverItem, setCurrentHoverItem] = useState(-1);

  const currentPos = currentHoverItem === -1 ? defaultPos : currentHoverItem;
  const asideRef = useRef<HTMLElement>(null);

  const { t } = useTranslation("common");

  useEffect(() => {
    if (!asideRef.current) return;
    if (isOpen) {
      asideRef.current.classList.add("w-64");
      asideRef.current.removeAttribute("style");
    } else {
      asideRef.current.classList.remove("w-64");
      asideRef.current.style.width = "72px";
    }
  }, [isOpen]);

  return (
    <aside
      ref={asideRef}
      className="h-[calc(100vh - 4rem)] flex flex-col justify-between bg-neutral p-2 transition-all"
    >
      <ul className="relative flex flex-col">
        <span
          style={{
            top: `${currentPos * 56}px`
          }}
          className={twMerge(
            "rounded-btn absolute z-0 h-[56px] w-full bg-base-200 transition-all duration-500 ease-in-out",
            currentPos === -1 ? "bg-transparent" : "bg-primary"
          )}
        />
        {items.map((item, itemIndex) => {
          if (item.submenus.length > 0) {
            return (
              <motion.li
                key={item.label}
                className="rounded-box z-10"
                onMouseEnter={() => setCurrentHoverItem(itemIndex)}
              >
                <div
                  className={!isOpen ? "tooltip tooltip-right" : ""}
                  data-tip={!isOpen ? t(item.label) : ""}
                  // onMouseLeave={() => {
                  //   setCurrentHoverItem(-1);
                  // }}
                >
                  <button
                    onMouseEnter={() => setCurrentHoverItem(itemIndex)}
                    className="flex w-full p-4 text-neutral-content transition-colors hover:text-neutral justify-between"
                    onClick={() => {
                      setCurrentOpenMenu((prevIndex) =>
                        prevIndex === itemIndex ? null : itemIndex
                      );
                    }}
                  >
                    <div className="flex gap-2">
                      <Icon className="text-2xl" icon={item.icon} />
                      {isOpen && (
                        <motion.span
                          className="whitespace-nowrap"
                          {...sidebarMotions.item}
                        >
                          {t(item.label)}
                        </motion.span>
                      )}
                    </div>
                    {isOpen && (
                      <Icon
                        className="text-2xl"
                        icon="eva:arrow-ios-downward-outline"
                        vFlip={currentOpenMenu === itemIndex}
                      />
                    )}
                  </button>
                </div>
                <AnimatePresence mode="wait" presenceAffectsLayout>
                  {currentOpenMenu === itemIndex && (
                    <motion.ul layout className="brightness-50 rounded-btn">
                      {item.submenus.map(
                        (
                          subitem: {
                            label: string;
                            href: string;
                            icon: string;
                          },
                          subitemIndex
                        ) => {
                          return (
                            <motion.li
                              key={subitem.label}
                              className="rounded-box z-10"
                              onMouseEnter={() =>
                                setCurrentHoverItem(
                                  subitemIndex + 1 + (itemIndex > 0 ? 1 : 0)
                                )
                              }
                            >
                              <div
                                className={
                                  !isOpen ? "tooltip tooltip-right" : ""
                                }
                                data-tip={!isOpen ? t(subitem.label) : ""}
                                // onMouseLeave={() => {
                                //   setCurrentHoverItem(-1);
                                // }}
                              >
                                <Link
                                  href={`${item.href}${subitem.href}`}
                                  onMouseEnter={() => {
                                    setCurrentHoverItem(
                                      subitemIndex + 1 + (itemIndex > 0 ? 1 : 0)
                                    );
                                  }}
                                  onMouseLeave={() => {
                                    setCurrentHoverItem(-1);
                                  }}
                                  className={twMerge(
                                    "block p-4 text-neutral-content transition-colors hover:text-neutral",
                                    currentHoverItem ===
                                      subitemIndex + 1 + (itemIndex > 0 ? 1 : 0)
                                      ? "text-neutral"
                                      : "text-neutral-content"
                                  )}
                                >
                                  <AnimatePresence mode="wait">
                                    <span className="flex gap-2">
                                      <Icon
                                        className="text-2xl"
                                        icon={subitem.icon}
                                      />
                                      {isOpen && (
                                        <motion.span
                                          className="whitespace-nowrap"
                                          {...sidebarMotions.item}
                                        >
                                          {t(subitem.label)}
                                        </motion.span>
                                      )}
                                    </span>
                                  </AnimatePresence>
                                </Link>
                              </div>
                            </motion.li>
                          );
                        }
                      )}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </motion.li>
            );
          }
          return (
            <motion.li
              key={item.label}
              className="rounded-box z-10"
              onMouseEnter={() =>
                setCurrentHoverItem(
                  itemIndex +
                    (currentOpenMenu !== null
                      ? items?.[currentOpenMenu as number]?.submenus.length ?? 0
                      : 0)
                )
              }
            >
              <div
                className={!isOpen ? "tooltip tooltip-right" : ""}
                data-tip={!isOpen ? t(item.label) : ""}
                // onMouseLeave={() => {
                //   setCurrentHoverItem(-1);
                // }}
              >
                <Link
                  href={item.href}
                  onMouseEnter={() => {
                    setCurrentHoverItem(
                      itemIndex +
                        (currentOpenMenu !== null
                          ? items?.[currentOpenMenu as number]?.submenus
                              .length ?? 0
                          : 0)
                    );
                  }}
                  onMouseLeave={() => {
                    setCurrentHoverItem(-1);
                  }}
                  className={twMerge(
                    "block p-4 text-neutral-content transition-colors hover:text-neutral",
                    currentHoverItem ===
                      itemIndex +
                        (currentOpenMenu !== null
                          ? items?.[currentOpenMenu as number]?.submenus
                              .length ?? 0
                          : 0)
                      ? "text-neutral"
                      : "text-neutral-content"
                  )}
                >
                  <AnimatePresence mode="wait">
                    <span className="flex gap-2">
                      <Icon className="text-2xl" icon={item.icon} />
                      {isOpen && (
                        <motion.span
                          className="whitespace-nowrap"
                          {...sidebarMotions.item}
                        >
                          {t(item.label)}
                        </motion.span>
                      )}
                    </span>
                  </AnimatePresence>
                </Link>
              </div>
            </motion.li>
          );
        })}
      </ul>
      <div className="flex flex-col">
        <AnimatePresence mode="wait">
          <div className="flex flex-col items-center">
            {isOpen && (
              <motion.span {...sidebarMotions.item} className="">
                ComunikiMe
              </motion.span>
            )}
            {isOpen && (
              <motion.span
                {...sidebarMotions.item}
                className="text-neutral-content"
              >
                Versão 1.0.0
              </motion.span>
            )}
          </div>
        </AnimatePresence>
        <div className="flex w-full flex-col">
          <button
            type="button"
            className="btn-ghost btn-circle btn ml-1 text-neutral-content"
            onClick={setIsOpen}
          >
            <Icon
              className="text-2xl"
              icon="material-symbols:menu-open-rounded"
              flip={isOpen ? "none" : "horizontal"}
            />
          </button>
        </div>
      </div>
    </aside>
  );
};

export default memo(Sidebar);
