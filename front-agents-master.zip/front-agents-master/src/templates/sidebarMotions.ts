export const sidebarMotions = {
  item: {
    initial: {
      opacity: 0,
      x: -20,
      scaleX: 0
    },
    animate: {
      opacity: 1,
      x: 0,
      scaleX: 1
    },
    exit: {
      opacity: 0,
      x: -20,
      scaleX: 0
    }
  }
}