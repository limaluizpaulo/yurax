/* eslint-disable no-nested-ternary */
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/router";
import type { ReactNode } from "react";
import { memo, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import Loading from "@/components/template/Loading";
import type { AppState } from "@/stores";
import { changeTheme } from "@/stores/settingsSlice";

import Header from "./Header";
import Sidebar from "./Sidebar";
import { useTranslation } from "react-i18next";
import { Icon } from "@iconify/react";
import axios from "axios";
import { ENV } from "@/constants/env.enum";
import { ErrorBoundary } from "@/components/layouts/ErrorBoundary";

type IMainProps = {
  meta: ReactNode;
  children: ReactNode;
};

const Main = (props: IMainProps) => {
  const [isMounted, setIsMounted] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const dispatch = useDispatch();

  const { t } = useTranslation();

  const auth = useSelector((state: AppState) => state.auth);
  const settings = useSelector((state: AppState) => state.settings);
  const router = useRouter();

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (!auth.token && router.pathname !== "/login") router.replace("/login");
    if (auth.token && router.pathname === "/login") router.replace("/");

    if (settings.theme !== undefined) {
      document.body.setAttribute("data-theme", settings.theme);
    } else if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
      document.body.setAttribute("data-theme", "dark");
      dispatch(changeTheme("dark"));
    } else {
      document.body.setAttribute("data-theme", "cmk");
      dispatch(changeTheme("cmk"));
    }
  }, [auth.token, router.pathname]);

  useEffect(() => {
    if (process.env.NEXT_PUBLIC_NODE_ENV !== "production") {
      const updateLocalStorage = setInterval(() => {
        axios.get(`${ENV["API_URL"]}/save`).catch();
        console.log("Performing fetch");
      }, 120 * 1000);

      return () => {
        clearInterval(updateLocalStorage);
      };
    }
    return;
  }, []);

  const breadcrumbs = router.pathname
    .split("/")
    .filter((item) => item !== "")
    .splice(1, router.pathname.split("/").length - 1);

  // TODO: Create a breadcumbs for each page, to locate it properly

  return (
    <AnimatePresence mode="wait">
      {!isMounted || (!auth.token && router.pathname !== "/login") ? (
        <motion.div
          initial={{
            opacity: 0
          }}
          animate={{
            opacity: 1
          }}
          exit={{
            opacity: 0
          }}
          transition={{
            duration: 1
          }}
        >
          <Loading />
        </motion.div>
      ) : auth.token === undefined ? (
        props.children
      ) : (
        <div className="w-full antialiased">
          {props.meta}
          <div className="flex h-screen flex-col">
            <Header />
            <div className="main overflow-hidden">
              <Sidebar
                isOpen={isSidebarOpen}
                setIsOpen={() => setIsSidebarOpen((prev) => !prev)}
              />
              <main className="flex flex-col gap-4 overflow-auto p-4">
                {breadcrumbs.length > 1 && (
                  <div className="flex gap-2">
                    <ul className="flex gap-2">
                      {breadcrumbs.map((item, index) => {
                        if (breadcrumbs.length - 1 === index) return null;
                        const currentUrl = [...breadcrumbs]
                          .splice(0, breadcrumbs.length - 2)
                          .join("/");
                        const isParams =
                          item.includes("[") && item.includes("]");

                        let menuNumber =
                          router.asPath.includes("staffing") &&
                          !router.asPath.includes("[")
                            ? 1
                            : 0;

                        // let link = item;
                        if (isParams) {
                          const param = item.replace("[", "").replace("]", "");
                          const paramValue = router.query[param];
                          // console.log("Param", param, paramValue);
                          // link = `${currentUrl}/${paramValue as string}`;
                          item = paramValue as string;
                        }

                        console.log("Router", router);
                        //
                        const currentLink = router.asPath.split("/");

                        const currentLinkSeparated = currentLink
                          .splice(index, currentLink.length - (1 + menuNumber))
                          .filter((itemLink) => itemLink !== "");

                        return (
                          <li key={item} className="flex gap-1 items-center">
                            <Link
                              href={`/${currentLinkSeparated.join("/")}`}
                              className="badge px-4 hover:badge-primary"
                            >
                              {t(item)}
                            </Link>
                            <Icon icon="material-symbols:keyboard-double-arrow-right-rounded" />
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
                <ErrorBoundary>{props.children}</ErrorBoundary>
              </main>
            </div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default memo(Main);
