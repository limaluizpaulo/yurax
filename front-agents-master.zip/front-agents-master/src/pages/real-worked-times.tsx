import CustomTable from "@/components/organisms/Table";
import AgentScaleBreak from "@/components/organisms/modals/scale/AgentBreak";
import { ENV } from "@/constants/env.enum";
import GenericDataToTable from "@/helper/transform/table/generic";
import { auth } from "@/stores/authSlice";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { ptBR } from "date-fns/locale";
import moment from "moment";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { DateRangePicker } from "react-next-dates";
import { useSelector } from "react-redux";

const RealWorkedTimesPage = () => {
  const { t } = useTranslation("common");
  const [currentOpenMenu, setCurrentOpenMenu] = useState<number | null>(null);
  const { token, user } = useSelector(auth);
  

  const [date, setDate] = useState({
    startDate: moment().subtract(1, "month").toDate(),
    endDate: moment().toDate()
  });

  const { data: realWorkedTimes, refetch: refetchScales } = useQuery({
    queryKey: ["realWorkedTimes"],
    queryFn: async () => {
      if (!user) return []; // Se o usuário ainda não estiver definido, retorne um array vazio

        const { data } = await axios.get(`${ENV.API_URL}/agents/time/work`, {
          headers: {
            Authorization: `Bearer ${token}`,
            startDate: date.startDate.toISOString(),
            endDate: date.endDate.toISOString(),
            agentId: user?.id
          }
        });

        if (!data || data?.length === 0) return [];   

        if (Array.isArray(data)){
          return data;
        } else {
          return [data];
        }
        
      
    },
    enabled: false,
  });

  useEffect(() => {
    if (user) {
      refetchScales(); // Refaz a query quando o usuário é definido
    }
  }, [user, refetchScales]);

  console.log("Real Worked Times: ", realWorkedTimes);

  return (
    <>
      <header className="flex justify-between">
        <h2 className="text-4xl font-bold">{t("real-worked-times")}</h2>
        <div className="flex gap-4">
          <DateRangePicker
            locale={ptBR}
            startDate={date.startDate}
            endDate={date.endDate}
            maxDate={new Date()}
            onStartDateChange={(startDate: any) => {
              setDate((prevDate) => ({ ...prevDate, startDate }));
            }}
            onEndDateChange={(endDate: any) => {
              setDate((prevDate) => ({ ...prevDate, endDate }));
            }}
          >
            {({ startDateInputProps, endDateInputProps }) => (
              <div className="input-group w-fit">
                <input
                  className="input w-[14ch] border-2 border-transparent bg-base-200 hover:bg-base-300 focus:border-primary focus:bg-neutral focus:text-neutral-content focus:outline-none"
                  {...startDateInputProps}
                  placeholder="dd/mm/aaaa"
                />
                <input
                  className="input w-[14ch] border-2 border-transparent bg-base-200 hover:bg-base-300 focus:border-primary focus:bg-neutral focus:text-neutral-content focus:outline-none"
                  {...endDateInputProps}
                  placeholder="dd/mm/aaaa"
                />
              </div>
            )}
          </DateRangePicker>
          <button
            type="button"
            onClick={() => refetchScales()}
            className="btn btn-primary"
          >
            {t("search")}
          </button>
        </div>
      </header>

      <CustomTable
        {...GenericDataToTable<{
          agent: string;
          _id: string;
          breaks: {
            _id: string;
            start: string;
            finish: string;
            type: number;
          };
          login: string;
          logout: string;
          __v: string;
        }>(
          realWorkedTimes,
          {},
          ["login", "logout", "breaks"],
          t,
          {
            login: "datetime",
            logout: "datetime"
          },
          ["agent", "_id", "__v"],
          "common"
        )}
        action={(index: number) => {
          return (
            <button
              onClick={() => {
                setCurrentOpenMenu((i) => (i === index ? null : index));
              }}
              className="mx-auto btn btn-primary btn-sm capitalize"
            >
              {t("show")}
            </button>
          );
        }}
      />

      <AgentScaleBreak
        isOpen={currentOpenMenu !== null}
        agentName="José"
        data={
          realWorkedTimes?.[currentOpenMenu!] ?? {
            login: "",
            logout: "",
            extraHours: "",
            breaks: []
          }
        }
        setIsOpen={() => {
          setCurrentOpenMenu(null);
        }}
      />
    </>
  );
};

export async function getStaticProps({ locale }: any) {
  return {
    props: {
      ...(await serverSideTranslations(locale))
    }
  };
}
export default RealWorkedTimesPage;
