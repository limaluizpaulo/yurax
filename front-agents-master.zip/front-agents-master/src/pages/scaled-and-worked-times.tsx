import CustomTable from "@/components/organisms/Table";
import AgentScaleBreak from "@/components/organisms/modals/scale/AgentBreak";
import { ENV } from "@/constants/env.enum";
import GenericDataToTable from "@/helper/transform/table/generic";
import { auth } from "@/stores/authSlice";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { ptBR } from "date-fns/locale";
import moment from "moment";
import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { DateRangePicker } from "react-next-dates";
import { useSelector } from "react-redux";

const ScaledAndWorkedTimesPage = () => {
  const { t } = useTranslation("common");
  const [currentOpenMenu, setCurrentOpenMenu] = useState<{
    selected: "workBreaks" | "scalesBreak" | null;
    index: number | null;
  }>({
    selected: null,
    index: null
  });
  const { token } = useSelector(auth);

  const [date, setDate] = useState({
    startDate: moment().subtract(1, "month").toDate(),
    endDate: moment().toDate()
  });

  const { data: scaledAndWorkedTimes, refetch: refetchScales } = useQuery({
    queryKey: ["scaledAndWorkedTimes"],
    queryFn: async () => {
      try {
        const { data } = await axios.get(`${ENV.API_URL}/agents/time/scalas`, {
          headers: {
            startDate: date.startDate.toISOString(),
            endDate: date.endDate.toISOString(),
            companyid: "62fd2cb7f6939da69824cf06",
            Authorization: `Bearer ${token}`
          }
        });

        if (!data || data?.length === 0) return [];

        return data;
      } catch (err) {
        console.log(err);
        return [];
      }
    }
  });

  console.log("Scaled", scaledAndWorkedTimes);
  // console.log("Real Worked Times: ", realWorkedTimes);

  return (
    <>
      <header className="flex justify-between">
        <h2 className="text-4xl font-bold">Tempo escalado x Tempo real</h2>
        <div className="flex gap-4">
          <DateRangePicker
            locale={ptBR}
            startDate={date.startDate}
            endDate={date.endDate}
            maxDate={new Date()}
            onStartDateChange={(startDate: any) => {
              setDate((prevDate) => ({ ...prevDate, startDate }));
            }}
            onEndDateChange={(endDate: any) => {
              setDate((prevDate) => ({ ...prevDate, endDate }));
            }}
          >
            {({ startDateInputProps, endDateInputProps }) => (
              <div className="input-group w-fit">
                <input
                  className="input w-[14ch] border-2 border-transparent bg-base-200 hover:bg-base-300 focus:border-primary focus:bg-neutral focus:text-neutral-content focus:outline-none"
                  {...startDateInputProps}
                  placeholder="dd/mm/aaaa"
                />
                <input
                  className="input w-[14ch] border-2 border-transparent bg-base-200 hover:bg-base-300 focus:border-primary focus:bg-neutral focus:text-neutral-content focus:outline-none"
                  {...endDateInputProps}
                  placeholder="dd/mm/aaaa"
                />
              </div>
            )}
          </DateRangePicker>
          <button
            type="button"
            // onClick={() => refetchScales()}
            className="btn btn-primary"
          >
            {t("search")}
          </button>
        </div>
      </header>
      <CustomTable
        {...GenericDataToTable<{
          agent: string;
          _id: string;
          breaks: {
            _id: string;
            start: string;
            finish: string;
            type: number;
          }[];
          scales: {
            _id: string;
            start: string;
            finish: string;
            type: number;
          }[];
          workLogin: string;
          workLogout: string;
          scalesLogin: string;
          scalesLogout: string;
          workBreaks: string;
          scalesBreak: string;
          __v: string;
        }>(
          scaledAndWorkedTimes,
          {},
          [
            "workLogin",
            "workLogout",
            "scalesLogin",
            "scalesLogout",
            "workBreaks",
            "scalesBreak"
          ],
          t,
          {
            workLogin: "datetime",
            workLogout: "datetime",
            scalesLogin: "datetime",
            scalesLogout: "datetime"
          },
          ["agent", "_id", "__v"],
          "common"
        )}
        action={(index: number) => {
          return (
            <div className="flex gap-4 w-fit">
              <button
                onClick={() => {
                  setCurrentOpenMenu((prev) =>
                    prev.index === index
                      ? {
                          selected: null,
                          index: null
                        }
                      : {
                          selected: "workBreaks",
                          index
                        }
                  );
                }}
                className="mx-auto btn btn-primary btn-sm capitalize"
              >
                Mostrar pausas efetiva
              </button>
              <button
                onClick={() => {
                  setCurrentOpenMenu((prev) =>
                    prev.index === index
                      ? {
                          selected: null,
                          index: null
                        }
                      : {
                          selected: "scalesBreak",
                          index
                        }
                  );
                }}
                className="mx-auto btn btn-primary btn-sm capitalize"
              >
                Mostrar pausas escaladas
              </button>
            </div>
          );
        }}
      />
      <AgentScaleBreak
        isOpen={currentOpenMenu.selected !== null}
        agentName="José"
        accessKey={currentOpenMenu.selected!}
        data={
          scaledAndWorkedTimes?.[currentOpenMenu.index!] ?? {
            login: "",
            logout: "",
            extraHours: "",
            breaks: []
          }
        }
        setIsOpen={() => {
          setCurrentOpenMenu({
            index: null,
            selected: null
          });
        }}
      />
    </>
  );
};

export async function getStaticProps({ locale }: any) {
  return {
    props: {
      ...(await serverSideTranslations(locale))
    }
  };
}

export default ScaledAndWorkedTimesPage;
