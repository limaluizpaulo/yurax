import { serverSideTranslations } from "next-i18next/serverSideTranslations";

import GeneralDashboardGraphs from "@/components/organisms/Charts/Dashboard/General";
import OptionalSelector from "@/components/molecules/OptionalSelector";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { ENV } from "@/constants/env.enum";
import { useSelector } from "react-redux";
import { auth } from "@/stores/authSlice";
import { useTranslation } from "react-i18next";

const Dashboard = () => {
  const [visualization, changeVisualization] = useState("Gráfico");
  const { token, user } = useSelector(auth);

  const { t } = useTranslation();

  const { isLoading, data } = useQuery({
    queryKey: ["charts"],
    queryFn: async () => {
      try {
        const { data } = await axios.get(`${ENV.API_URL}/agents/adherence`, {
          headers: {
            startDate: new Date("2021-01-01").toISOString(),
            endDate: new Date().toISOString(),
            Authorization: `Bearer ${token}`,
            agentId: "647e01d2e9db28bca091e329",
          }
        });

        return data[0];
      } catch (err) {
        console.log(err);

        return {};
      }
    }
  });

  return (
    <>
      <header className="flex justify-between">
        <h2 className="text-4xl font-bold">Dashboard Aderência</h2>
        <OptionalSelector
          options={["Gráfico", "Tabela"]}
          label="Visualização"
          defaultSelected={0}
          onChange={changeVisualization}
        />
      </header>
      {visualization === "Gráfico" ? (
        <GeneralDashboardGraphs data={data} />
      ) : (
        <ul className="bg-neutral text-neutral-content rounded-md p-4 grid grid-cols-2">
          {Object.entries(data).map(([key, value]) => {
            if (typeof value === "object") {
              return (
                <>
                  {Object.entries(value as Record<string, string>).map(
                    ([newKey, newValue]) => (
                      <span key={newKey}>
                        {t(newKey)}: {newValue}
                      </span>
                    )
                  )}
                </>
              );
            }

            return (
              <li key={key}>
                {t(key)}: {value as string}
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
};

export default Dashboard;

export async function getStaticProps({ locale }: any) {
  return {
    props: {
      ...(await serverSideTranslations(locale, ["common", "table"]))
    }
  };
}
