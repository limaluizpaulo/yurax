import { useState } from "react";

import { useSelector } from "react-redux";
import { auth } from "@/stores/authSlice";
import { ENV } from "@/constants/env.enum";
import { useRouter } from "next/router";
import axios from "axios";

const Profile = () => {
  const { user } = useSelector(auth);
  const router = useRouter();


  return (
    <>
      <form
        className="container"
        style={{ flex: 1 }}
        onSubmit={async (e) => {
          e.preventDefault();

          const newUser = Object.fromEntries(
            new FormData(e.target as HTMLFormElement)
          ) as {
            firstName: string;
            lastName: string;
            email: string;
            role: string;
            password: string;
            confirmPassword: string;
          };

          if (newUser.password !== newUser.confirmPassword) {
            alert("As senhas não coincidem");
            return;
          }

          let payload: { [key: string]: string } = {};


        
            payload = {
              ...payload,
              password: newUser.password,
            };
          

          try {
            console.log(user)
            if (user) {
              const response = await axios.patch(`${ENV.API_URL}/login/update/`, payload, {
                headers: {
                  agentId: user.id,
                },
              }
              
              );
            

            if (response.status === 200) {
              alert("Usuário atualizado com sucesso");
            }
          }
          } catch (err) {
            console.log(err);
          }
        }}
      >
        <header
          className="flex p-2 flex-col"
          style={{ marginRight: "var(--spacing-md)" }}
        >
          <div
            className="flex gap-2"
            style={{
              fontSize: "1.5rem",
              fontWeight: "bold",
              marginBottom: "2rem",
            }}
          >
            {" "}
            {user && user.firstName} {user && user.lastName}
          </div>



          <div className="flex gap-2 flex-col">
            <label htmlFor="email" className="text-lg font-bold">
              Email
            </label>
            <input
              disabled
              id="email"
              name="email"
              className="input-bordered input bg-base-200"
              style={{ maxWidth: "40ch" }}
              defaultValue={user && user.email}
            />
          </div>

            <>
              <div className="flex gap-2 flex-col">
                <label htmlFor="password" className="text-lg font-bold">
                  Senha
                </label>
                <input
                  autoComplete="off"
                  id="password"
                  name="password"
                  type="password"
                  className="input-bordered input bg-base-200"
                  style={{ maxWidth: "40ch" }}
                />
              </div>
              <div className="flex gap-2 flex-col">
                <label htmlFor="confirmPassword" className="text-lg font-bold">
                  Confirmar Senha
                </label>
                <input
                  autoComplete="off"
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  className="input-bordered input bg-base-200"
                  style={{ maxWidth: "40ch" }}
                />
              </div>
            </>
         
        </header>

        <footer
          className="container row"
          style={{ marginTop: "10px", alignSelf: "end", maxWidth: "40ch",
          display: "flex",
          justifyContent: "space-between",
        }}
        >
          <button
            type="button"
            className="btn btn-neutral ring"
            onClick={() => {
              setTimeout(() => {
                router.push(`/`);
              }, 200);
            }}
          >
            Voltar
          </button>
          <button type="submit" className="btn btn-primary ring">
            Atualizar
          </button>
        </footer>
      </form>
    </>
  );
};

export default Profile;
