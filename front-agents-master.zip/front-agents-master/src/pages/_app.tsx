/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
import "@/styles/header.sass";
import "react-next-dates/dist/style.scss";
import "react-widgets/styles.css";
import "@/styles/global.sass";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query"; // eslint-disable-line import/no-extraneous-dependencies
// import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import type { AppProps } from "next/app";
import { appWithTranslation } from "next-i18next"; // eslint-disable-line import/no-extraneous-dependencies

import { Meta } from "@/layouts/Meta";
import { wrapper } from "@/stores";
import Main from "@/templates/Main";
import { useEffect } from "react";
import { ENV } from "@/constants/env.enum";

const queryClient = new QueryClient();

const MyApp = ({ Component, pageProps }: AppProps) => {
  // const [shouldRender, setShouldRender] = useState(false);
  useEffect(() => {
    // async function initMocks() {
    // const { setupMocks } = await import("mocks");
    // await setupMocks();
    // setShouldRender(true);
    // }

    if (ENV["ENVIRONMENT"] === "development") {
      console.log("Starting mock server");
      // initMocks();
      // require("../mock");
      // setShouldRender(true);
    }
  }, []);
  return (
    <Main
      meta={
        <Meta
          title="Agents"
          description="Some dummy description"
        />
      }
    >
      <QueryClientProvider client={queryClient}>
        <Component {...pageProps} />
        {/* <ReactQueryDevtools initialIsOpen={false} /> */}
      </QueryClientProvider>
    </Main>
  );
};

export default appWithTranslation(wrapper.withRedux(MyApp));
