import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import Link from "next/link";
import { useTranslation } from "react-i18next";
import { twMerge } from "tailwind-merge";
import { Icon } from "@iconify/react";

const routes = [
  {
    label: "scales",
    icon: "majesticons:table-plus-line",
    href: "/scales"
  },
  {
    label: "real-worked-times",
    icon: "ri:time-fill",
    href: "/real-worked-times"
  },
  {
    label: "adherence",
    icon: "mdi:chart-line",
    href: "/general"
  },
  // {
  //   label: "scaled-and-worked-times",
  //   icon: "ri:time-fill",
  //   href: "/scaled-and-worked-times",
  //   submenus: []
  // }
];
const MainPage = () => {
  const { t } = useTranslation();
  return (
    <>
      <ul className="grid grid-cols-3 flex-1 gap-8">
        {routes.map((route) => {
          return (
            <li
              key={route.label}
              className={twMerge(
                "relative w-full text-neutral-content h-1/2 overflow-hidden rounded-btn bg-neutral hover:bg-primary p-4 transition-all"
              )}
            >
              <Link
                href={route.href}
                className="absolute z-10 w-full h-full top-0 right-0 flex items-center text-center justify-end text-[3rem] font-medium px-4"
              >
                {t(route.label)}
              </Link>
              <Icon
                className="absolute text-[10rem] -rotate-45 -bottom-8 opacity-50"
                icon={route.icon}
              />
            </li>
          );
        })}
      </ul>
    </>
  );
};

export async function getStaticProps({ locale }: any) {
  return {
    props: {
      ...(await serverSideTranslations(locale))
    }
  };
}

export default MainPage;
