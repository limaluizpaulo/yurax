import "react-toastify/dist/ReactToastify.css";

import { serverSideTranslations } from "next-i18next/serverSideTranslations";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { useDispatch, useSelector } from "react-redux";

import LogoCmk from "@/components/atom/Icons/LogoCmk";
import LanguagesMenu from "@/components/molecules/LanguagesMenu";
import { auth, login, resetLoginAttempt } from "@/stores/authSlice";
import { ToastContainer, toast } from "react-toastify";
import { useEffect, useRef } from "react";

const LoginPage = () => {
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm();

  const authentication = useSelector(auth);

  const { t } = useTranslation(["common"]);

  const toastHandler = useRef<any>(null);

  const dispatch = useDispatch();

  useEffect(() => {
    // toastHandler.current = toast("");

    if (authentication?.state === "error") {
      toastHandler.current = toast(t("error-login"));
      toast.update(toastHandler.current, {
        render: t("error-login")
      });
      console.log("There was an error while trying out login");
      setTimeout(() => {
        dispatch(resetLoginAttempt());
      }, 2000);
    } else {
      console.log("There was no errors");
    }
  }, [authentication?.state]);

  return (
    <div className="relative flex h-screen w-screen items-center justify-center bg-neutral">
      <header className="absolute right-8">
        <LanguagesMenu />
      </header>
      <div className="card max-w-md bg-base-100 shadow-lg">
        <div className="card-body">
          <LogoCmk />
          <form
            onSubmit={handleSubmit((data) => {
              dispatch(login(data));
            })}
            className="flex flex-col text-neutral-content"
          >
            <div className="form-control">
              <label className="label">
                <span className="label-text">{t("email")}</span>
              </label>
              <input
                type="email"
                placeholder="Email"
                className="input-bordered input"
                {...register("email", { required: true })}
              />
              {errors.email && (
                <span className="text-error">
                  {t("is-required", { option: t("email") })}
                </span>
              )}
            </div>
            <div className="form-control">
              <label className="label">
                <span className="label-text capitalize">{t("password")}</span>
              </label>
              <input
                type="password"
                placeholder={String(t("password"))}
                className="input-bordered input"
                {...register("password", { required: true })}
              />
              {errors.password && (
                <span className="text-error">
                  {t("is-required", { option: t("password") })}
                </span>
              )}
            </div>
            <button type="submit" className="btn-primary btn mt-4 self-end">
              {t("sign-in")}
            </button>
          </form>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export async function getStaticProps({ locale }: any) {
  return {
    props: {
      ...(await serverSideTranslations(locale))
    }
  };
}

export default LoginPage;
