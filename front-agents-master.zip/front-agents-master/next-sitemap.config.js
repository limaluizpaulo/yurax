/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'https://comunikime-pi.vercel.app', // FIXME: Change to the production URL
  generateRobotsTxt: true,
};
